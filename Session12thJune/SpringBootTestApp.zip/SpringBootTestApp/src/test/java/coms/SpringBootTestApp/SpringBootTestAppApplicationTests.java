package coms.SpringBootTestApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootTestAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
