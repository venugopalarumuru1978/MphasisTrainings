package coms.SpringBootTestApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootTestAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootTestAppApplication.class, args);
		System.out.println("Server Started....");
	}
}
