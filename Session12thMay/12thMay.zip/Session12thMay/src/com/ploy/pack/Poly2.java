package com.ploy.pack;

public class Poly2 {

	public void Big(int x, int y)
	{
		if(x>y)
			System.out.println(x + " and " + y + " Big number is " + x);
		else
			System.out.println(x + " and " + y + " Big number is " + y);
	}
	
	public void Big(float x, float y)
	{
		if(x>y)
			System.out.println(x + " and " + y + " Big number is " + x);
		else
			System.out.println(x + " and " + y + " Big number is " + y);
	}

	public void Big(int x, float y)
	{
		if(x>y)
			System.out.println(x + " and " + y + " Big number is " + x);
		else
			System.out.println(x + " and " + y + " Big number is " + y);
	}
}
