package com.ploy.pack;

public class PolyMain {

	public static void main(String[] args) {
			Poly1.Area(1.5f, 2.5f);
			Poly1.Area(1.5f);
			Poly1.Area(4,5);
			
			System.out.println("------------------");
			
			Poly2  p2 = new Poly2();
			
			p2.Big(5, 6);
			p2.Big(12.34f, 11.05f);
			p2.Big(34, 10.56f);
	}

}
