package com.ploy.pack;
// this is not overriding
class Parent
{
	private int x;
	public void get(int x)
	{
		this.x = x;
	}
	
	public void put()
	{
		System.out.println(x + " Square Value " + (x*x));
	}
}

class Child extends Parent
{
	public void get(int x)
	{
		super.get(x);
		System.out.println(x + " Cube Value " + (x*x*x));
	}
}

public class OverrideMain2 {

	public static void main(String[] args) {

		Child dc = new Child();
		dc.get(10);
		dc.put();	
	}
}
