package com.ploy.pack;
// this is overriding
class DemoParent
{
	public void get(int x)
	{
		System.out.println(x + " Square Value " + (x*x));
	}
}

class DemoChild extends DemoParent
{
	public void get(int x)
	{
		System.out.println(x + " Cube Value " + (x*x*x));
	}
}

public class OverrideMain {

	public static void main(String[] args) {

		DemoParent dp = new DemoParent();
		dp.get(10);  // parent class method
		//DemoChild dc = new DemoChild();
		//dp = dc; // Override
				// or
		dp = new DemoChild();
		dp.get(10); // child class method
	}
}
