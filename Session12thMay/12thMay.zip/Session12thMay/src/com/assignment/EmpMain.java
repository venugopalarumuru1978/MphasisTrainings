package com.assignment;

import java.util.Scanner;

public class EmpMain {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
			Loan loan = new Loan();
			System.out.println("Employee Number : ");
			int empno = sc.nextInt();
			System.out.println("Employee Name : ");
			String ename = sc.next();
			System.out.println("Type of Emp:  1. Permanent Emp\t2. Temporary Emp");
			int ch = sc.nextInt();
			
			switch(ch)
			{
			case 1:
				System.out.println("Employee Basic Pay : ");
				double bs = sc.nextDouble();
				PermanentEmployee  pe = new PermanentEmployee(empno, ename, bs);
				pe.calculateSalary();
				System.out.println("Loan Amount : " + loan.calculateLoanAmount(pe));
				break;
			case 2:
				System.out.println("Working Hours : ");
				int whours = sc.nextInt();
				System.out.println("Wages per Hour : ");
				int wages =sc.nextInt();
				
				TemporaryEmployee  te = new TemporaryEmployee(empno, ename, whours, wages);
				te.calculateSalary();
				System.out.println("Loan Amount : " + loan.calculateLoanAmount(te));
				break;
			}
	}
}
