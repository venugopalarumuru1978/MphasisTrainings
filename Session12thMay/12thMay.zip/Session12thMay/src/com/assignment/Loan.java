package com.assignment;

public class Loan {

	public double calculateLoanAmount(Employee employeeObj)
	{
		double loanAmt = 0.0;
		
		if(employeeObj instanceof PermanentEmployee)
		{
			System.out.println("Permanent Employee Salary : " + employeeObj.getSalary());
			loanAmt = employeeObj.getSalary()*0.15f;
		}
		if(employeeObj instanceof TemporaryEmployee)
		{
			System.out.println("Temporary Employee Salary : " + employeeObj.getSalary());
			loanAmt = employeeObj.getSalary()*0.10f;			
		}
		return loanAmt;
	}
}
