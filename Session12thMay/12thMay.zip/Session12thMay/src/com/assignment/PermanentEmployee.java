package com.assignment;

public class PermanentEmployee extends Employee {

	private double basicPay;
	
	public double getBasicPay() {
		return basicPay;
	}

	public void setBasicPay(double basicPay) {
		this.basicPay = basicPay;
	}

	public PermanentEmployee(int employeeId, String employeeName, double basicPay) {
		super(employeeId, employeeName);
		this.basicPay = basicPay;
	}

	@Override
	public void calculateSalary() 
	{
		double pf = this.getBasicPay()*0.12f;
		System.out.println("12% Pf Amount : " + pf);
		this.setSalary(this.getBasicPay()-pf);
	}
}
