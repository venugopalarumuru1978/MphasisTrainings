package com.exceptionpack;

import java.util.Scanner;

public class Excep5 {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		try
		{
			System.out.println("Enter age of the person ");
			int age = sc.nextInt();
			
			if(age<18)
				throw new InvalidAgeException("Error ! Person age not qualified");
			else
				System.out.println("Voter List Process is Done");
		}
		catch(InvalidAgeException ex)
		{
			System.err.println(ex);
		}
		catch(Exception ex)
		{
			System.out.println(ex + " Only number has to give");
		}
		finally
		{
			System.out.println("Finally Block");
		}
		sc.close();
	}
}
