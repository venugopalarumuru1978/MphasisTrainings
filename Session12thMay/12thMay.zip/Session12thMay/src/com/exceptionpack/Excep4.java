package com.exceptionpack;
import java.io.IOException;

/*
 * read() :-  this method is used to read a char from keyboard, it returns
 * 	it's ascii value.
 * variable = System.in.read()
*/

public class Excep4 {
	
	public static void main(String[] args) {
		try
		{
			System.out.println("Enter any alphabet : ");
			int ch = System.in.read();
			System.out.println("Given Alphabet : " + (char)ch);
		}
		catch(IOException ex)
		{
			
		}
	}
}
