package com.exceptionpack;

public class InvalidAgeException extends Exception {

	public InvalidAgeException(String arg)
	{
		super(arg);
	}
}
