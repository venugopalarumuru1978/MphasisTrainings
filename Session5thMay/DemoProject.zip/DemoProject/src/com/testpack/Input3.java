package com.testpack;

// Accept a number then find it's last digit.
// n= 123 
// result = 3

import java.util.Scanner;

public class Input3 {

	public static void main(String[] args) {
		Scanner scObj = new Scanner(System.in);
		System.out.println("Enter Any Number : ");
		int n =  scObj.nextInt();
		
		int lastDigit = n%10;
		System.out.println("Last Digit is : " + lastDigit);
	}
}