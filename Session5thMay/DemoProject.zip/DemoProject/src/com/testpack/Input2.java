package com.testpack;

/* 
 * Calculate area of circle 
	area = PI*radius*radius
	PI = 3.14
*/
import java.util.Scanner;

public class Input2 {

	public static void main(String[] args) {
		Scanner scObj = new Scanner(System.in);
		final float PI = 3.14f;  // constant variable
		System.out.println("Enter Radius of the circle");
		float r = scObj.nextFloat();
		float area = PI*r*r;
		System.out.println("Area of Circle is : " + area);
	}
}