package com.testpack;

// Accept a 3 digit number then find it's first, second and last digit.
// n= 123
// fd = 1, sd = 2, ld =3

import java.util.Scanner;

public class Input4 {

	public static void main(String[] args) {
		Scanner scObj = new Scanner(System.in);
		System.out.println("Enter Any 3 digit Number(100-999) : ");
		int n =  scObj.nextInt();
		
		int firstDigit = n/100;
		System.out.println("First Digit : " + firstDigit);
		
		int secondDigit = (n/10)%10;
		System.out.println("Second Digit : " + secondDigit);
		
		int lastDigit = n%10;
		System.out.println("Last Digit is : " + lastDigit);
	}
}