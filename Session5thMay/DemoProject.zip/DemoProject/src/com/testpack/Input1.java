package com.testpack;

// Accept a number then find square and cube of that numbers. 
import java.util.Scanner;

public class Input1 {

	public static void main(String[] args) {
		Scanner scObj = new Scanner(System.in);
		System.out.println("Enter Any Number : ");
		int n =  scObj.nextInt();
		
		System.out.println("Given Value is : " + n);
		System.out.println("Square Value is : " + (n*n));
		System.out.println("Cube Value is : " + (n*n*n));
	}
}