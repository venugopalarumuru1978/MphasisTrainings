
public class Test2 {

	public static void main(String[] args) {
	
		int x = 100;
		System.out.println("X value is : " + x);
		
		float y = 34.45f;
		System.out.println("Y value is : " + y);
		
		char ch = 'A';
		System.out.println("Character Value is : " + ch);
		
		boolean b = true;
		System.out.println("Boolean Value is : " +b);
	}
}
