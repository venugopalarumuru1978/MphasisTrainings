
public class Test3 {

	public static void main(String[] args) {
		//Example of Big number from two numbers using conditional operators
		int x =10, y = 5;
		
		int big = (x>y) ? x : y;
		
		System.out.println(x + " and " + y + " Big Value is : " + big);
	}
}
