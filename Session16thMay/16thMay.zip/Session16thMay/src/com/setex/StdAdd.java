package com.setex;

import java.util.*;

public class StdAdd {

	public static void main(String[] args) {
		Set<Student>  setStd = new HashSet<Student>();

		Student std = new Student(1001, "Pavan", "Java", 10000.00f);
		setStd.add(std);

		std = new Student(1002, "Karan", "Java", 10000.00f);
		setStd.add(std);
		
		std = new Student(1003, "Sumathi", "Java", 10000.00f);
		setStd.add(std);

		std = new Student(1004, "Karunya", "Java", 10000.00f);
		setStd.add(std);

		std = new Student(1005, "Kamala", "Java", 10000.00f);
		setStd.add(std);
		
		
		//System.out.println(lstStd);
		
		for(Student s : setStd)
		{
			System.out.println(s.getRollno() + "\t" + s.getSname() + "\t" + s.getCourse() + "\t" + s.getFees());
		}
		
		System.out.println("Using Iterator");
		
		Iterator itr = setStd.iterator();
		
		while(itr.hasNext())
		{
			Student s = (Student)itr.next();
			System.out.println(s.getRollno() + "\t" + s.getSname() + "\t" + s.getCourse() + "\t" + s.getFees());
		}
	}
}
