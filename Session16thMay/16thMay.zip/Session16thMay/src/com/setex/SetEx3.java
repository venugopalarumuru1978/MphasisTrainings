package com.setex;
import java.util.*;
public class SetEx3 {

	public static void main(String[] args) {
		
		Set<String>  setStr = new TreeSet<String>();
		
		setStr.add("Venugopal");
		setStr.add("Praveen");
		setStr.add("Lokesh");
		setStr.add("Venugopal");
		setStr.add("Mahesh");
		setStr.add("Abhiram");
		
		System.out.println(setStr);
		
		for(String s : setStr)
		{
			System.out.println(s);
		}
		
		System.out.println("Using Iterator");
		
		Iterator itr = setStr.iterator();
		
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
 
	}

}
