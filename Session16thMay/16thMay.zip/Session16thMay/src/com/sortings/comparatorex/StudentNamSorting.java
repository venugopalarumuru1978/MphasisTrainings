package com.sortings.comparatorex;

import java.util.Comparator;

public class StudentNamSorting implements Comparator<Student> {

	@Override
	public int compare(Student s1, Student s2) {
		// TODO Auto-generated method stub
		if(s1.getSname().compareTo(s2.getSname())>0)
				return 1;
		if(s1.getSname().compareTo(s2.getSname())==0)
			return 0;
		return -1;	
	}
}
