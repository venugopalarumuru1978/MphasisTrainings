package com.sortings.comparatorex;

import java.util.Comparator;

public class RollNoSorting implements Comparator<Student> {

	@Override
	public int compare(Student s1, Student s2) {
		// TODO Auto-generated method stub
		if(s1.getRollno()>s2.getRollno())
			return 1;
		if(s1.getRollno()==s2.getRollno())
			return 0;
		return -1;
	}
}
