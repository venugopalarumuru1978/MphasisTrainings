package com.sortings.comparatorex;

public class Student {

	private int rollno;
	private String sname;
	private int total;
	private float avg;
	
	public int getRollno() {
		return rollno;
	}
	public void setRollno(int rollno) {
		this.rollno = rollno;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	public float getAvg() {
		return avg;
	}
	public void setAvg(float avg) {
		this.avg = avg;
	}
	public Student(int rollno, String sname, int total, float avg) {
		super();
		this.rollno = rollno;
		this.sname = sname;
		this.total = total;
		this.avg = avg;
	}
}
