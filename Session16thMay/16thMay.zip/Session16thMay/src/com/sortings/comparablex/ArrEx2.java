package com.sortings.comparablex;

import java.util.*;

public class ArrEx2 {

	public static void main(String[] args) {

		List<Integer>  lstInt = new ArrayList<Integer>();
		
		lstInt.add(102);
		lstInt.add(100);
		lstInt.add(105);
		lstInt.add(101);
		lstInt.add(103);
		
		System.out.println("List Values :\n" + lstInt);
		
		Collections.sort(lstInt);
		
		System.out.println("List Values in Asending order :\n" + lstInt);
		
		Collections.sort(lstInt, Collections.reverseOrder());
		
		System.out.println("List Values in Desending order :\n" + lstInt);
	}

}
