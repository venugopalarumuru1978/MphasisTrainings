package com.sortings.comparablex;

import java.util.Arrays;

public class ArrEx1 {

	public static void main(String[] args) {

		int x[] = {10,-9, 4, 1};
		
		System.out.println("Array Values : ");
		for(int n : x)
		{
			System.out.print(n + "  ");
		}

		Arrays.sort(x);
		
		System.out.println("\nArray Values in asending order : ");
		for(int n : x)
		{
			System.out.print(n + "  ");
		}
		
		System.out.println("\nArray Values in desending order : ");
		for(int i= x.length-1;i>=0;i--)
			System.out.print(x[i] + "  ");
	}

}
