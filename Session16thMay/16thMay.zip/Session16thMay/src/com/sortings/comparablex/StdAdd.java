package com.sortings.comparablex;

import java.util.*;

public class StdAdd {

	public static void main(String[] args) {
		List<Student>  lstStd = new ArrayList<Student>();

		Student std = new Student(1001, "Pavan", 300, 50.00f);
		lstStd.add(std);

		std = new Student(1003, "Kiran", 400, 65.00f);
		lstStd.add(std);
		
		std = new Student(1005, "Abhiram", 500, 80.00f);
		lstStd.add(std);
		
		std = new Student(1002, "Baskar", 460, 75.00f);
		lstStd.add(std);

		std = new Student(1004, "Murali", 560, 90.00f);
		lstStd.add(std);

		//System.out.println(lstStd);
		System.out.println("Before Sorting ");
		for(Student s : lstStd)
		{
			System.out.println(s.getRollno() + "\t" + s.getSname() + "\t" + s.getTotal() + "\t" + s.getAvg());
		}

		Collections.sort(lstStd);
			/*
			 * Collections is a class, sort() is static method for sorting 
			 * of colections like list, set, map etc...
			 */
		System.out.println("---------------\nAfter Sorting :\n-------------------");
		for(Student s : lstStd)
		{
			System.out.println(s.getRollno() + "\t" + s.getSname() + "\t" + s.getTotal() + "\t" + s.getAvg());
		}
		Collections.sort(lstStd, Collections.reverseOrder());
		System.out.println("---------------\nAfter Sorting in Desending :\n-------------------");
		for(Student s : lstStd)
		{
			System.out.println(s.getRollno() + "\t" + s.getSname() + "\t" + s.getTotal() + "\t" + s.getAvg());
		}

	}
}
