package com.mapex;
import java.util.*;
public class ModifyMap {

	public static void main(String[] args) {
		Map<Integer,String> stdinfo = new HashMap<Integer,String>();
		
		stdinfo.put(1003, "Lokesh");
		stdinfo.put(1002, "Naresh");
		stdinfo.put(1005, "Paramesh");
		stdinfo.put(1004, "Ramesh");
		stdinfo.put(1001, "Mahesh");

		System.out.println(stdinfo);
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter any key : ");
		int rno = sc.nextInt();
		
		if(stdinfo.containsKey(rno))
		{
			System.out.println("Existed : It's Value is : " +  stdinfo.get(rno));
			System.out.println("Enter new value to modify : ");
			String sname = sc.next();
			stdinfo.replace(rno, sname);
			System.out.println("After Modify :\n" + stdinfo);
		}
		else
			System.out.println("Not Found....");
	}
}
