package com.mapex;
import java.util.*;
public class MapEx4 {

	public static void main(String[] args) {
		Map<Integer,String> stdinfo = new HashMap<Integer,String>();
		
		stdinfo.put(1003, "Lokesh");
		stdinfo.put(1002, "Naresh");
		stdinfo.put(1005, "Paramesh");
		stdinfo.put(1004, "Ramesh");
		stdinfo.put(1001, "Mahesh");

		System.out.println(stdinfo);
		
		// traversing with iterator in two ways
		Set setkeys = stdinfo.keySet();  // keyset() method returns only keys from map
		Iterator itr = setkeys.iterator();
		while(itr.hasNext())
		{
			int key = (Integer)itr.next();
			System.out.println("Key : " + key + " Value is : " + stdinfo.get(key));
		}
		System.out.println("--------------------------------");
		
		Set sets = stdinfo.entrySet(); // converting map into set.
		Iterator itr1 = sets.iterator();
		
		while(itr1.hasNext())
		{
			Map.Entry map =   (Map.Entry)itr1.next();
			System.out.println("Key : " + map.getKey() + " Value is : " + map.getValue());
		}
		
	}
}
