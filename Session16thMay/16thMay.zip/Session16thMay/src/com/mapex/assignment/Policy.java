package com.mapex.assignment;
import java.util.*;
public class Policy {

	Map<Integer, String>  policys =  new TreeMap<Integer,String>();
	
	public void addPolicyDetails(int pno, String pname)
	{
		policys.put(pno, pname);
	}
	
	public Map<Integer, String>  ViewAll()
	{
		return policys;
	}
	
	public List<Integer>  searchBasedOnPolicyType(String ptype)
	{
		List<Integer>  pids = new ArrayList<Integer>();
		
		for(Map.Entry m : policys.entrySet())
		{
			String pname = (String)m.getValue();
			
			if(pname.contains(ptype))
				pids.add((Integer)m.getKey());
		}
		return pids;
	}
}
