package com.mapex.assignment;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;
public class PolicyMain {

	public static void main(String[] args) throws IOException
	{
		Scanner sc = new Scanner(System.in);
		Policy p = new Policy();
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));;
		while(true)
		{
			System.out.println("1. Add Policy\n2. View All Policies\n3. Search Policy\n4. Exit");
			System.out.println("Pick Ur Choice : ");
			int ch = sc.nextInt();
			
			switch(ch)
			{
			case 1:
				System.out.println("Policy ID ");
				int pno = sc.nextInt();
				System.out.println("Policy Name ");
				String pname = br.readLine();
				p.addPolicyDetails(pno, pname);
				break;
			case 2:
				Map<Integer, String>  pall = p.ViewAll();
				for(Map.Entry m : pall.entrySet())
				{
					System.out.println("| " + m.getKey() + " | " + m.getValue());
				}
				break;
			case 3:
				System.out.println("Enter Search Keywords");
				String str = br.readLine();
				List<Integer> pnumbers = p.searchBasedOnPolicyType(str);
				
				if(pnumbers.isEmpty())
					System.out.println("No Policies are existed");
				else
					System.out.println(pnumbers);
				break;
			case 4:
				System.out.println("Thanks for Using App");
				System.exit(0);
			}
		}
		
	}
}
