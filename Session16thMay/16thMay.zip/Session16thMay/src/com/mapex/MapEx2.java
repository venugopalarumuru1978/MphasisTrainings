package com.mapex;
import java.util.*;
public class MapEx2 {

	public static void main(String[] args) {
		Map<Integer,String> stdinfo = new LinkedHashMap<Integer,String>();
		
		stdinfo.put(1003, "Lokesh");
		stdinfo.put(1002, "Naresh");
		stdinfo.put(1005, "Paramesh");
		stdinfo.put(1004, "Ramesh");
		stdinfo.put(1001, "Mahesh");

		System.out.println(stdinfo);
		
		for(Map.Entry  std :  stdinfo.entrySet())
		{
			System.out.println(std);
			System.out.println("Key : " + std.getKey() + "\tValue : " + std.getValue());
		}
	}

}
