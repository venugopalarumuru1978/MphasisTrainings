package com.sync;

class SharedResource2
{
	public  synchronized static void Wish(String sname)
	{
		for(int i=1;i<=5;i++)
		{
			System.out.println("Good Evening : " + sname);
			try
			{
				Thread.sleep(1000);
			}
			catch(Exception ex)
			{}
		}
	}
}

class SyncStatic extends Thread
{
	private String sname;
	
	public SyncStatic(String sname)
	{
		this.sname  = sname;
	}
	
	public void run()
	{
		SharedResource2.Wish(sname);
	}
}

public class Sync3Main {

	public static void main(String[] args) {
		
		SyncStatic  sm1 = new SyncStatic("Venugopal");
		sm1.start();

		SyncStatic  sm2 = new SyncStatic("Priya Bhavani");
		sm2.start();
	}

}
