package com.sync;

class SharedResource1
{
	public void Wish(String sname)
	{
		System.out.println("Thread Begins ");
		synchronized(this)
		{
			for(int i=1;i<=5;i++)
			{
				System.out.println("Good Evening : " + sname);
				try
				{
					Thread.sleep(1000);
				}
				catch(Exception ex)
				{}
			}
		}
		System.out.println("Thread Ends ");
	}
}

class SyncBlock extends Thread
{
	private String sname;
	private SharedResource1 sr;
	
	public SyncBlock(String sname, SharedResource1 sr)
	{
		this.sname  = sname;
		this.sr = sr;
	}
	
	public void run()
	{
		sr.Wish(sname);
	}
}

public class Sync2Main {

	public static void main(String[] args) {
		SharedResource1 sr = new SharedResource1();
		
		SyncBlock  sm1 = new SyncBlock("Venugopal", sr);
		sm1.start();

		SyncBlock  sm2 = new SyncBlock("Priya Bhavani", sr);
		sm2.start();
	}
}
