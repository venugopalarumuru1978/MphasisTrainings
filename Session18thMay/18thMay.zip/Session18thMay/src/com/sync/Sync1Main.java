package com.sync;

class SharedResource
{
	public  synchronized void Wish(String sname)
	{
		for(int i=1;i<=5;i++)
		{
			System.out.println("Good Evening : " + sname);
			try
			{
				Thread.sleep(1000);
			}
			catch(Exception ex)
			{}
		}
	}
}

class SyncMethod extends Thread
{
	private String sname;
	private SharedResource sr;
	
	public SyncMethod(String sname, SharedResource sr)
	{
		this.sname  = sname;
		this.sr = sr;
	}
	
	public void run()
	{
		sr.Wish(sname);
	}
}

public class Sync1Main {

	public static void main(String[] args) {
		SharedResource sr = new SharedResource();
		
		SyncMethod  sm1 = new SyncMethod("Venugopal", sr);
		sm1.start();

		SyncMethod  sm2 = new SyncMethod("Priya Bhavani", sr);
		sm2.start();
	}

}
