package com.threads;

class MyThread3 implements Runnable
{
	public void run()
	{
		System.out.println("This is Thread-1 ");
	}
}

class MyThread4 implements Runnable
{
	public void run()
	{
		System.out.println("This is Thread-2 ");
	}
}

public class ThreadEx2 {

	public static void main(String[] args) {
		MyThread3 mt3 = new MyThread3();
		Thread th1 = new Thread(mt3);
		th1.start();
	
		
		MyThread4 mt4 = new MyThread4();
		Thread th2 = new Thread(mt4);
		th2.start();
		
		th2.setPriority(Thread.MAX_PRIORITY);
		th1.setPriority(Thread.MIN_PRIORITY);
		
		System.out.println("Th1 Priority : " +  th1.getPriority());
		System.out.println("Th2 Priority : " +  th2.getPriority());
		
	}

}
