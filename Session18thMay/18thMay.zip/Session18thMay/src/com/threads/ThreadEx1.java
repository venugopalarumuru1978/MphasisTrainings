package com.threads;

class MyThread1 extends Thread
{
	public void run()
	{
		System.out.println("This is Thread-1 ");
	}
}

class MyThread2 extends Thread
{
	public void run()
	{
		System.out.println("This is Thread-2 ");
	}
}

public class ThreadEx1 {

	public static void main(String[] args) {
		MyThread1 mt1 = new MyThread1();
		//here  every object of thread class is one thread.
		mt1.start();
		MyThread2  mt2 = new MyThread2();
		mt2.start();
		
		System.out.println("This is main thread");
	}

}
