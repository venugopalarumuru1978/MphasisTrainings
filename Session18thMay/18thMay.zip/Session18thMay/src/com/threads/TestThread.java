package com.threads;

class Test1 extends Thread
{
	public void run()
	{
		for(int i=1;i<=5;i++)
		{
			System.out.println("Thread - 1");
			try
			{
				Thread.sleep(1000);
			}
			catch(Exception ex)
			{}
		}
	}
}

class Test2 extends Thread
{
	public void run()
	{
		for(int i=1;i<=5;i++)
		{
			System.out.println("Thread - 2");
			try
			{
				Thread.sleep(1000);
			}
			catch(Exception ex)
			{}
		}
	}
}

public class TestThread {

	public static void main(String[] args) {
		Test1 t1 = new Test1();
		t1.start();
		
		Test2 t2 = new Test2();
		t2.start();
		
		System.out.println("T1 Thread Name : " + t1.getName());
		System.out.println("T2 Thread Name : " + t2.getName());
		t1.setName("Pavan");
		t2.setName("Kalyan");
		System.out.println("T1 Thread Name : " + t1.getName());
		System.out.println("T2 Thread Name : " + t2.getName());
	}

}
