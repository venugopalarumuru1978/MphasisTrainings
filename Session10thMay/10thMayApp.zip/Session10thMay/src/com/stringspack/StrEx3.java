package com.stringspack;
import java.util.Scanner;
public class StrEx3 {

	public static void main(String[] args) {
		String str = "Academy for Best Computer Education";
		System.out.println("Given String is : " + str);
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Sub String to Search");
		String temp = sc.next();
		
		if(str.contains(temp))
			System.out.println("Sub String Existed");
		else
			System.out.println("Sub String is not Existed");
	}
}
