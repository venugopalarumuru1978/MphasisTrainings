package com.stringspack;
import java.util.Scanner;

public class LeastOffer {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter No of Items to purchase ");
		int n = sc.nextInt();
		
		String products[] = new String[n];  // storing product details
		float discounts[] = new float[n];
		String pname[] = new String[n];
		
		for(int i=0;i<n;i++)
		{
			System.out.println("Enter " + (i+1) + " Product Details ");
			products[i] = sc.next();
		}

		for(int i=0;i<n;i++)
		{
			String product = products[i];
			
			String temp[] = product.split(",");
			pname[i] = temp[0];
			int amt =  Integer.parseInt(temp[1]);
			int disc = Integer.parseInt(temp[2]);
			
			float discAmt = amt*(disc/100.00f);
			discounts[i] = discAmt;
		}
		
		float small = discounts[0];
		int p=0;
		for(int i=0;i<n;i++)
		{
			if(small>discounts[i])
			{
				small = discounts[i];
				p++;
			}
		}
		System.out.println(pname[p] + " getting least discount " + small);
	}
}
