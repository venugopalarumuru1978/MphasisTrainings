package com.stringspack;
import java.util.Scanner;
public class StrEx7 {

	public static void main(String[] args) {
		String str = "Academy for Best Computer Education";
		
		System.out.println("Given String is : " + str);
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the sub string");
		String sub = sc.next();
		
		System.out.println(str.indexOf(sub));
		
		
	}
}
