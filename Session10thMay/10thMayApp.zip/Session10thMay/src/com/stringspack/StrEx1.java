package com.stringspack;

public class StrEx1 {

	public static void main(String[] args) {
		String str = "Academy for Best Computer Education";
		System.out.println("Given String is : " + str);
		System.out.println("Upper Case String : " + str.toUpperCase());
		System.out.println("Lower Case String : " + str.toLowerCase());
		System.out.println("String Length : " +  str.length());
		
		System.out.println("First Char : " + str.charAt(0));
		
		for(int i=0;i<str.length();i++)
		{
			System.out.print(str.charAt(i) + " ");
		}
	}
}
