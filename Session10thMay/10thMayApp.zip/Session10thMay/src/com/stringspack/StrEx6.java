package com.stringspack;

public class StrEx6 {

	public static void main(String[] args) {
		String str = "Academy for Best Computer Education";
		
		System.out.println("Given String is : " + str);
		
		String sptStr[] = str.split(" ");// space
		
		for(int i=0;i<sptStr.length;i++)
		{
			System.out.println(sptStr[i]);
		}
		
		String phone = "987-1234-345";
		System.out.println("Phone Number : " + phone);
		String ph[] = phone.split("-");

		for(int i=0;i<ph.length;i++)
		{
			System.out.println(ph[i]);
		}
		
	}
}
