package com.stringspack;

import java.util.Scanner;
public class StrEx9 {
// string array
	public static void main(String[] args) {
		String str[] = new String[5];
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter 5 Strings ");
		for(int i=0;i<str.length;i++)
		{
			str[i] = sc.nextLine();  // it take string including spaces
		}
		
		System.out.println("Given Strings :- ");
		for(int i=0;i<str.length;i++)
		{
			System.out.println(str[i]);
		}
	}
}
