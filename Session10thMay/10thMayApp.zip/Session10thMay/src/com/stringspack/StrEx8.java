package com.stringspack;

public class StrEx8 {
// string array
	public static void main(String[] args) {
		String str[] = {"Java Training", "Mphasis Corporate", "SimpliLearn"};
		System.out.println("Given Strings :- ");
		for(int i=0;i<str.length;i++)
		{
			System.out.println(str[i]);
		}
	}
}
