package com.stringspack;
import java.util.Scanner;
public class StrEx2 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter two strings ");
		String str1 = sc.next();
		String str2 = sc.next();
		
		//if(str1.equals(str2))
		if(str1.equalsIgnoreCase(str2))
			System.out.println("Both are Same");
		else
			System.out.println("Both are not Same");
	}
}
