package com.stringspack;
import java.util.Scanner;
public class StrEx4 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter two strings ");
		String str1 = sc.next();
		String str2 = sc.next();
		
		if(str1.compareTo(str2)>0)
			System.out.println("First String is Big");
		else if(str1.compareTo(str2)<0)
			System.out.println("Second String is Big");
		else if(str1.compareTo(str2)==0)
			System.out.println("Both are Same");
	}
}
