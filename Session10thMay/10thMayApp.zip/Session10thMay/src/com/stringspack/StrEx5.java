package com.stringspack;
import java.util.Scanner;
public class StrEx5 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter two strings ");
		String str1 = sc.next();
		String str2 = sc.next();
		
		System.out.println("Concatenated Strings : " + str1.concat(str2));
		System.out.println("First String : " + str1);
		System.out.println("Second String : " + str2);
	}
}
