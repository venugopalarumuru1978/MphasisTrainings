package com.oopsPack;

import java.util.Scanner;

public class Student {

	private int rollno;
	private String sname;
	private int sub1,sub2;
	
	public void GetStudentInfo()
	{
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Roll Number : ");
		rollno = sc.nextInt();

		System.out.println("Student Name : ");
		sname = sc.next();

		System.out.println("Subject 1 Marks : ");
		sub1 = sc.nextInt();

		System.out.println("Subject 2 Marks : ");
		sub2 = sc.nextInt();
	}
	
	public void PrintStudentDetails()
	{
		System.out.println("Roll Number : " + rollno);
		System.out.println("Student Name : " + sname);
		System.out.println("Subject 1 Marks : " + sub1);
		System.out.println("Subject 2 Marks : " + sub2);
		int total = sub1+sub2;
		System.out.println("Total Marks : " + total);
		float avg = total/2.0f;
		System.out.println("Percentage Marks : " + avg);
		if(sub1>=35 && sub2>=35)
			System.out.println(sname + " is Passed");
		else
			System.out.println(sname + " is Failed");
	}
}
