package com.oopsPack;

public class DemoMain {

	public static void main(String[] args) {
		DemoClass dc1 = new DemoClass();
		dc1.getdata();
		dc1.putdata();
		
		DemoClass dc2 = new DemoClass();
		dc2.getdata();
		dc2.putdata();
	}
}
