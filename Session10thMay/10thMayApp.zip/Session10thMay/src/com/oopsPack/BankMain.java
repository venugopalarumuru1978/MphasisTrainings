package com.oopsPack;

public class BankMain {

	public static void main(String[] args) {
		Bank cust1 = new Bank();
		cust1.GetCustomerInfo("Pavan", 100000);
		Bank cust2 = new Bank();
		cust2.GetCustomerInfo("Karan", 200000);
		Bank cust3 = new Bank();
		cust3.GetCustomerInfo("Karana", 400000);
		
		cust1.printCustomer();
		System.out.println("--------------");
		cust2.printCustomer();
		System.out.println("--------------");
		cust3.printCustomer();
		System.out.println("--------------");

		Bank.getBankBalance();

	}

}
