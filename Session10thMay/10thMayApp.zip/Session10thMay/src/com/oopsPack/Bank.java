package com.oopsPack;

public class Bank {

	private String cname;
	private int accbal;
	private static int bankbal;
	
	public void GetCustomerInfo(String cn, int bal)
	{
		cname = cn;
		accbal = bal;
		bankbal = bankbal+accbal;
	}
	
	public void printCustomer()
	{
		System.out.println("Customer name : " + cname);
		System.out.println("Balance in Account : " + accbal);
	}
	
	public static void getBankBalance()
	{
		System.out.println("Total Amount in Bank : " + bankbal);
	}
}
