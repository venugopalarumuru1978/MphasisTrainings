package com.oopsPack;

public class DemoStatic {

	private static int x, y;
	
	public static void getValues()
	{
		x = 100;
		y = 200;
	}
	
	public static void printValues()
	{
		System.out.println("X val : " + x);
		System.out.println("Y val : " + y);
	}
	
}
