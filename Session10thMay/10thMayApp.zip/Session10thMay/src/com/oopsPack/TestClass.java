package com.oopsPack;

import java.util.Scanner;

public class TestClass {

	private int x;
	
	void getValue()
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter any value ");
		x = sc.nextInt();
	}
	
	void printValue()
	{
		System.out.println(x + " Square Value : " + (x*x));
		System.out.println(x + " Cube Value : " + (x*x*x));
	}
	
	public static void main(String[] args) {
	
			TestClass tc1 = new TestClass();
			tc1.getValue();
			tc1.printValue();
	}

}
