package com.oopsPack;

public class StasticMain {

	public static void main(String[] args) {
		DemoStatic.getValues();
		DemoStatic.printValues();
	}
}
