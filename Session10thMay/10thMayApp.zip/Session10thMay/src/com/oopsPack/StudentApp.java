package com.oopsPack;

public class StudentApp {

	public static void main(String[] args) {
		Student std1 = new Student();
		std1.GetStudentInfo();
		std1.PrintStudentDetails();
		
		System.out.println("--------------------");
		
		Student std2 = new Student();
		std2.GetStudentInfo();
		std2.PrintStudentDetails();
	}

}
