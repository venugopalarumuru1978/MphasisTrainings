package com.hiber.apps;

import java.util.Scanner;

import com.hiber.model.Student;
import com.hiber.service.StdOperations;

public class UpdateStudent {

	public static void main(String[] args) {
		StdOperations  so = new StdOperations();
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter Roll Number : ");
		int rno = sc.nextInt();
		
		Student s = so.SearchStudent(rno);

		if(s!=null)
		{
			System.out.println("Present name : " +  s.getSname());
			System.out.println("Enter New Name of the student");
			s.setSname(sc.next());
			
			if(so.UpdateStudentName(s).equals("Success"))
				System.out.println("Student Name Updated...");
		}
		else
			System.out.println("Not Found....");
	}
}
