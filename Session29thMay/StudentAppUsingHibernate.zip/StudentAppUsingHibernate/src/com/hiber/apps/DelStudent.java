package com.hiber.apps;

import java.util.Scanner;

import com.hiber.service.StdOperations;

public class DelStudent {

	public static void main(String[] args) {
		StdOperations  so = new StdOperations();
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter Roll Number to Delete : ");
		int rno = sc.nextInt();
		
		boolean b = so.DeleteStudent(rno);
		
		if(b==true)
			System.out.println("Student Deleted....");
		else
			System.out.println("Student Not Found....");
	}
}
