package com.hiber.apps;

import java.util.Scanner;

import com.hiber.model.Student;
import com.hiber.service.StdOperations;

public class SearchStudentApp {

	public static void main(String[] args) {
		StdOperations  so = new StdOperations();
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter Roll Number : ");
		int rno = sc.nextInt();
		
		Student s = so.SearchStudent(rno);

		if(s!=null)
			System.out.println(s.getRollno() + "\t" + s.getSname() + "\t" + s.getCourse() + "\t" + s.getFees());
		else
			System.out.println("Not Found....");
	}
}
