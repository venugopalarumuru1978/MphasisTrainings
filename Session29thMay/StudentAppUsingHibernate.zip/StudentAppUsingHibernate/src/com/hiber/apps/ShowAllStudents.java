package com.hiber.apps;

import java.util.List;

import com.hiber.model.Student;
import com.hiber.service.StdOperations;

public class ShowAllStudents {

	public static void main(String[] args) {
		
		StdOperations  so = new StdOperations();
		List<Student>  sinfo =  so.ShowAll();
		
		for(Student s : sinfo)
			System.out.println(s.getRollno() + "\t" + s.getSname() + "\t" + s.getCourse() + "\t" + s.getFees());
	}

}
