package com.hiber.apps;

import java.util.Scanner;

import com.hiber.model.Student;
import com.hiber.service.StdOperations;

public class StudentAdd {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		Student std = new Student();
		StdOperations so = new StdOperations();
		
		System.out.println("Student Name : ");
		std.setSname(sc.next());
		System.out.println("Student Course : ");
		std.setCourse(sc.next());
		System.out.println("Course Fees : ");
		std.setFees(sc.nextFloat());
		
		if(so.AddNewStudent(std).equals("Success"))
			System.out.println("New Student is Added....");
		else
			System.out.println("Error... ! New Student is  Not Added....");
	}
}
