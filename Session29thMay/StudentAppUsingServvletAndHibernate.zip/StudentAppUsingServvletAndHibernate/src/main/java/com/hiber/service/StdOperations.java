package com.hiber.service;

import java.io.Serializable;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import com.hiber.dbcon.HibernateConfig;
import com.hiber.model.Student;

public class StdOperations {

	private SessionFactory sfactory = null;
	public StdOperations()
	{
		sfactory = HibernateConfig.getSessionFactory();
	}
	
	public String AddNewStudent(Student std)
	{
		String result = "Error";
		Session sObj = sfactory.openSession();
		Transaction trns = sObj.beginTransaction();
		Serializable s = sObj.save(std);
		trns.commit();
		
		if(s!=null)
			result =  "Success";
		
		return result;
	}
	
	public List<Student>  ShowAll()
	{
		Session sObj = sfactory.openSession();
		Query qry = sObj.createQuery("from Student");  // Student is a class
		List<Student>  sall = qry.list();
		return sall;
	}
	
	public Student SearchStudent(int rno)
	{
		Session sObj = sfactory.openSession();
		Student std = null;
		Query qry = sObj.createQuery("from Student where rollno=:r");
								// here student is a class name and rollno is a variable
		qry.setParameter("r", rno);
		List<Student>  sall =  qry.list();
		
		if(!sall.isEmpty())
			std = sall.get(0);
		
		return std;
	}
	
	public boolean DeleteStudent(int rno)
	{
		Session sObj = sfactory.openSession();
		boolean b = false;
		
		Transaction trans = sObj.beginTransaction();
		Query qry = sObj.createQuery("Delete from Student where rollno=:r");
		qry.setParameter("r", rno);
		int res = qry.executeUpdate();
		if(res>=1)
			b = true;
		
		return b;
	}
	
	public String UpdateStudentName(Student std)
	{
		Session sObj = sfactory.openSession();
		String result = "Error";
		Transaction trans = sObj.beginTransaction();
		Query qry = sObj.createQuery("Update Student set sname=:sn where rollno=:r");
		qry.setParameter("sn", std.getSname());
		qry.setParameter("r", std.getRollno());
		int res = qry.executeUpdate();
		if(res>=1)
			result = "Success";
		
		return result;
	}
}
