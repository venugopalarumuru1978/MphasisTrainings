package com.hiber.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity // it will tell that class need to convert into table
@Table(name="Customerinfo")
public class Customer {

	@Id  // specifies that primary key
	@GeneratedValue  // it will generate values automatically
	@Column(name="custid")
	private int cid;
	
	@Column(name="customername")
	private String cname;
	
	private String email;
	
	@Column(name="phonenumber")
	private String phone;
	
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
	
	
}
