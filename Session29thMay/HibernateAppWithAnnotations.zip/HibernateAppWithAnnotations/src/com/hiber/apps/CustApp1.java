package com.hiber.apps;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.hiber.model.Customer;

public class CustApp1 {

	public static void main(String[] args) {
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");

		Customer cust = new Customer();
		cust.setCname("Murali");
		cust.setEmail("murali@gmail.com");
		cust.setPhone("9988123456");
		
		SessionFactory sf = cfg.buildSessionFactory();
		Session session = sf.openSession();
		Transaction trans = session.beginTransaction();

		session.save(cust);
		trans.commit();
		
		sf.close();
		session.close();
		
		System.out.println("New Customer is Added...");
	}

}
