package com.assignment2;

import java.util.Scanner;

public class EmpMain {

	private static Scanner sc = new Scanner(System.in);
	
	public static Employee getEmployeeDetails()
	{
		Employee emp = new Employee();
		System.out.println("Employee Number : ");
		emp.setEmployeeId(sc.nextInt());
		System.out.println("Enter Employee Name : ");
		emp.setEmployeeName(sc.next());
		System.out.println("Enter Employee Basic Salary : ");
		emp.setSalary(sc.nextDouble());
		return emp;
	}
	
	public static int getPFPercentage()
	{
		System.out.println("Enter PF Percentage : ");
		int pf = sc.nextInt();
		return pf;
	}
	
	public static void main(String[] args) {

		Employee empinfo = EmpMain.getEmployeeDetails();
		int pf = EmpMain.getPFPercentage();
		empinfo.calculateNetSalary(pf);
		
		System.out.println("Employee Number : " + empinfo.getEmployeeId());
		System.out.println("Employee Name : " + empinfo.getEmployeeName());
		System.out.println("Employee Salary : " + empinfo.getSalary());
		System.out.println("Employee Net Salary : " + empinfo.getNetSalary());
	}

}
