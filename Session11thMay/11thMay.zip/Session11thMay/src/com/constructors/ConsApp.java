package com.constructors;

public class ConsApp {

	public static void main(String[] args) {
		DemoCons  dc1 = new DemoCons();
		dc1.printvalues();
		
		System.out.println("------------");
		
		ConsParam cp1 = new ConsParam(45,56);
		cp1.printvalues();
		
		ConsParam cp2 = new ConsParam(66,77);
		cp2.printvalues();
		
		System.out.println("------------");
		
		MultipleCons mc1 = new MultipleCons();  // it calls cons without arg
		mc1.printvalues();
		
		MultipleCons mc2 = new MultipleCons(500,900);  // it calls cons with arg
		mc2.printvalues();
		
	}
}
