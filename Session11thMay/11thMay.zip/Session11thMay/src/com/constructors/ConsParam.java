package com.constructors;

public class ConsParam {

	private int x, y;
	
	public ConsParam(int x, int y)
	{
		this.x = x;
		this.y = y;
		System.out.println("It is Constructor with para meters");
	}
	
	public void printvalues()
	{
		System.out.println("X value is : " + x);
		System.out.println("Y value is : " + y);
	}
}
