package com.constructors;

public class DemoCons {

	private int x, y;
	
	public DemoCons()
	{
		x = 100;
		y = 200;
		System.out.println("It is Constructor");
	}
	
	public void printvalues()
	{
		System.out.println("X value is : " + x);
		System.out.println("Y value is : " + y);
	}
}
