package com.constructors;

public class MultipleCons {

	private int x, y;
	
	public MultipleCons()
	{
		x = 12;
		y = 14;
		System.out.println("It is Constructor without para meters");
	}
	
	public MultipleCons(int x, int y)
	{
		this.x = x;
		this.y = y;
		System.out.println("It is Constructor with para meters");
	}
	
	public void printvalues()
	{
		System.out.println("X value is : " + x);
		System.out.println("Y value is : " + y);
	}
}
