package com.gs_pack;

import java.util.Scanner;

public class EmpOperations {

	private Employee emp = new Employee();
	
	public void GetEmployeeInfo()
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Employee Number : ");
		emp.setEmpno(sc.nextInt());
		
		System.out.println("Employee Name : ");
		emp.setEname(sc.next());
		
		System.out.println("Employee Job : ");
		emp.setJob(sc.next());
		
		System.out.println("Employee Salary : ");
		emp.setSalary(sc.nextFloat());
	}
	
	public void printEmpDetails()
	{
		System.out.println("Emp Number : " + emp.getEmpno());
		System.out.println("Emp Name : " + emp.getEname());
		System.out.println("Emp Job : " + emp.getJob());
		System.out.println("Emp Salary : " + emp.getSalary());
	}
}
