package com.gs_pack;

public class gsMain {

	public static void main(String[] args) {
		DemoGettersAndSetters  dgs = new DemoGettersAndSetters();
		dgs.setX(100); // calling setter method
		System.out.println("X value is : " + dgs.getX());  // calling getter method	
	}
}
