package com.gs_pack;

public class DemoGettersAndSetters {

	private int x;
	
	public void setX(int x)
	{
		this.x = x;
	}
	
	public int getX()
	{
		return x;
	}
	
}
