package com.gs_pack;

public class EmpApp {

	public static void main(String[] args) {
		EmpOperations  empinfo = new EmpOperations();
		empinfo.GetEmployeeInfo();
		empinfo.printEmpDetails();
		

	}

}
