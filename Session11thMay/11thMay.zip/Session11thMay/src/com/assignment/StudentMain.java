package com.assignment;

import java.util.Scanner;

public class StudentMain {

	public static void main(String[] args) {
		Student std = null;
		Scanner sc =new Scanner(System.in);
		System.out.println("Student ID : ");
		int sid = sc.nextInt();
		System.out.println("Student Name : ");
		String sname = sc.next();
		System.out.println("Student Address : ");
		String adrs = sc.next();
				
		while(true)
		{
			System.out.println("Are u from NIT(yes/no) : ");
			String chk = sc.next();
			
			if(chk.equalsIgnoreCase("yes")  || chk.equalsIgnoreCase("no")) 
			{
				if(chk.equalsIgnoreCase("yes"))
				{
					std = new Student(sid,sname,adrs); // 3arg cons
				}
			
				if(chk.equalsIgnoreCase("no"))
				{
					System.out.println("College name : ");
					String clg = sc.next();
					std = new Student(sid, sname, adrs,clg); // 4 arg cons
				}
				break;
			}	
			System.out.println("Wrong Input");
		}
		
		System.out.println("Student Id : " + std.getStudentId());
		System.out.println("Student Name : " + std.getStudentName());
		System.out.println("Student Address : " + std.getStudentAddress());
		System.out.println("College Name : " + std.getCollegeName());
	}
}
