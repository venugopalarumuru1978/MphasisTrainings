package com.abstraction;

public class BikeMain {

	public static void main(String[] args) {
		
		Bike b = new Honda();
		b.BikeInfo();
		b.run();
		
		Bike b2 = new BMW();
		b2.BikeInfo();
		b2.run();
		

	}

}
