package com.abstraction;

public abstract class Bike {

	public void BikeInfo()
	{
		System.out.println("Bikes are two type(Gear & GearLess");
	}
	
	abstract  void run();  // abstract method
}

class Honda extends Bike
{
	@Override
	void run() {
		System.out.println("It is a 200CC Bike");
	}
}

class BMW extends Bike
{
	@Override
	void run() {
		System.out.println("It is a 1000CC Bike");
	}
}