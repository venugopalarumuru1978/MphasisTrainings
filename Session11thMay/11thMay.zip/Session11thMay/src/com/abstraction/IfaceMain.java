package com.abstraction;

interface Iface1
{
	void getdata(int x);
	void putdata();
}
interface  Iface2
{
	void testFun();
}
class TestInterface implements Iface1, Iface2
{
	private int x;
	@Override
	public void getdata(int x) {
		// TODO Auto-generated method stub
		this.x = x;
	}

	@Override
	public void putdata() {
		// TODO Auto-generated method stub
		System.out.println(x + " Square Value is " + (x*x));
	}

	@Override
	public void testFun() {
		// TODO Auto-generated method stub
		System.out.println("This is Test Fun method");
	}
}





public class IfaceMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		TestInterface  tf1 = new TestInterface();
		tf1.getdata(10);
		tf1.putdata();
		*/
		
		Iface1 if1 = new TestInterface();;
		
		if1.getdata(10);
		if1.putdata();
		
		Iface2 if2 = new TestInterface();
		if2.testFun();	
	}
}
