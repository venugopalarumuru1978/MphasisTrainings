package com.inheritance;
// multi level 
abstract class StdBio
{
	protected  String sname, course;
	
	public void getStdInfo(String sname, String course)
	{
		this.sname = sname;
		this.course = course;
	}
}

class Marks extends StdBio
{
	protected int sub1, sub2;
	
	public void getMarksInfo(int sub1, int sub2)
	{
		this.sub1 = sub1;
		this.sub2 = sub2;
	}
}

class MarkSheet extends Marks
{
	public void PrintMarkSheet()
	{
		System.out.println("Student Name : " + sname);
		System.out.println("Student Course : " + course);
		System.out.println("Sub-1 Marks : " + sub1);
		System.out.println("Sub-2 Marks : " + sub2);
		System.out.println("Total Marks : " + (sub1+sub2));
	}
}

public class MulMain {

	public static void main(String[] args) {
		MarkSheet ms = new MarkSheet();
		ms.getStdInfo("Pavan", "Java");
		ms.getMarksInfo(60, 70);
		ms.PrintMarkSheet();
	}
}
