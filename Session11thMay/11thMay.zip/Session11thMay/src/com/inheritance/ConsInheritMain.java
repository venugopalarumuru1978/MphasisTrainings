package com.inheritance;

class Demo1
{
	public Demo1()
	{
		System.out.println("Parent class constructor");
	}
}


class Demo2 extends Demo1
{
	public Demo2()
	{
		System.out.println("Child class constructor");
	}
}


public class ConsInheritMain {

	public static void main(String[] args) {
	Demo2 d2 = new Demo2();
	

	}

}
