package com.inheritance;
// single 
class DemoBase
{
	protected int x, y;
	
	public void getdata(int x, int y)
	{
		this.x = x;
		this.y = y;
	}
}

class DemoDerived extends DemoBase
{
	private int sum;
	
	public void putdata()
	{
		sum = x+y;
		System.out.println("X val : " + x);
		System.out.println("Y val : " + y);
		System.out.println("Sum val : " + sum);
	}
}

public class SinMain {

	public static void main(String[] args) {

		DemoDerived dd = new DemoDerived();
		dd.getdata(10, 20);
		dd.putdata();	
	}

}
