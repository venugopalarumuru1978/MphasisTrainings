package com.inheritance;

class Demo11
{
	protected int x;
	public Demo11(int x)
	{
		this.x = x;
		System.out.println("Parent class constructor");
	}
}

class Demo22 extends Demo11
{
	private int y;
	public Demo22(int a, int b)
	{
		super(a);
		this.y = b;
	System.out.println("Child Class Constructor");
	}
	
	public void print()
	{
		System.out.println("X value is : " + x);
		System.out.println("Y value is : " + y);
	}
}


public class ConsInheritMain2 {

	public static void main(String[] args) {
	Demo22 d2 = new Demo22(34,56);
	d2.print();
	}
}
