package com.student.servletinfo;
import com.student.service.StdOpertions;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class DeleteStd
 */
@WebServlet("/DeleteStd")
public class DeleteStd extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeleteStd() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String rno = request.getParameter("rno");
		System.out.println(rno);
		StdOpertions sos = new StdOpertions();
		if(sos.DeleteStudent(Integer.parseInt(rno))==true);
			response.sendRedirect("ShowAllStudents.jsp");
	}

}
