package com.student.service;

import java.io.Serializable;
import java.util.List;

import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.student.dbcon.HiberConfig;
import com.student.model.Student;

public class StdOpertions {

	private SessionFactory sfactory = null;
	public StdOpertions()
	{
		sfactory = HiberConfig.getSessionFactory();
	}
	
	public String AddNewStudent(Student std)
	{
		String result = "error";
	
		Session session = sfactory.openSession();
		Transaction trans =  session.beginTransaction();
		Serializable s = session.save(std);
		trans.commit();
		
		if(s!=null)
			result = "Success";
		return result;
	}
	
	public List<Student>  ShowAll()
	{
		Session session = sfactory.openSession();
		TypedQuery qry = session.createQuery("from Student");
		List<Student> sall = qry.getResultList();
		return sall;
	}
	
	public Student  UserCheck(String email, String pwd)
	{
		Student std = null;
		Session session = sfactory.openSession();
		TypedQuery qry = session.createQuery("from Student where email=:em and password=:pwd");
		qry.setParameter("em", email);
		qry.setParameter("pwd", pwd);
		List<Student> sall = qry.getResultList();
		
		if(!sall.isEmpty())
			std = sall.get(0);
		
		return std;
	}
	
	public boolean DeleteStudent(int rno)
	{
		
		boolean b = false;
		Session session = sfactory.openSession();
		Transaction trans =  session.beginTransaction();
		TypedQuery qry = session.createQuery("Delete from Student where rollno=:rno");
		qry.setParameter("rno", rno);
		int res = qry.executeUpdate();
		trans.commit();
		
		if(res>=1)
			b = true;
		
		return b;
	}
	
	public Student  GetStdDetails(int rno)
	{
		Student std = null;
		Session session = sfactory.openSession();
		TypedQuery qry = session.createQuery("from Student where rollno=:r");
		qry.setParameter("r", rno);;
		List<Student> sall = qry.getResultList();
		
		if(!sall.isEmpty())
			std = sall.get(0);
		
		return std;
	}
	
	public String UpdateStdinfo(Student std)
	{
		String result = "error";
		Session session = sfactory.openSession();
		Transaction trans =  session.beginTransaction();
		TypedQuery qry = session.createQuery("Update Student set sname=:sn, gender=:gen, location=:loc where rollno=:rno");
		qry.setParameter("sn", std.getSname());
		qry.setParameter("gen", std.getGender());
		qry.setParameter("loc", std.getLocation());
		qry.setParameter("rno", std.getRollno());
		
		int res = qry.executeUpdate();
		trans.commit();
		
		if(res>=1)
			result = "Success";
		
		return result;
	}
	
	public boolean ChangePasword(String npass, int rno)
	{
		boolean b = false;
		Session session = sfactory.openSession();
		Transaction trans =  session.beginTransaction();
		TypedQuery qry = session.createQuery("Update Student set password=:ps where rollno=:rno");
		qry.setParameter("ps", npass);
		qry.setParameter("rno", rno);
		
		int res = qry.executeUpdate();
		trans.commit();
		
		if(res>=1)
			b = true;
		
		return b;
	}
}
