package com.hibernate.service;

import java.util.List;

import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.hibernate.dbcon.HiberConfig;
import com.hibernate.models.Department;
import com.hibernate.models.Employee;

public class DeptOperations {

	private SessionFactory sfactory = null;
	public DeptOperations()
	{
		sfactory = HiberConfig.getSessionFactory();
	}
	
	public void AddDept(Department dept)
	{
		Session session = sfactory.openSession();
		Transaction trans = session.beginTransaction();
		session.save(dept);
		trans.commit();
	}
	
	public List<Department>  ViewDepts()
	{
		Session session = sfactory.openSession();
		TypedQuery  qry = session.createQuery("from Department");
		
		List<Department>  dall = qry.getResultList();
		return dall;
	}
	
	public void AddEmp(Employee emp)
	{
		Session session = sfactory.openSession();
		Transaction trans = session.beginTransaction();
		session.save(emp);
		trans.commit();
	}
	
	
	public List<Department>  ViewEmpsBasedOnDept(int dno)
	{
		Session session = sfactory.openSession();
		TypedQuery  qry = session.createQuery("from Department where deptno=:d");
		qry.setParameter("d", dno);
		List<Department>  dall = qry.getResultList();
		return dall;
	}
}
