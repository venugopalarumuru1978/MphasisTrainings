package com.hibernate.models;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

@Entity
@Table(name="DeptInfo")
public class Department {

	@Id
	@GeneratedValue
	private int deptno;
	private String deptname;
	private String location;
	
	@OneToMany(targetEntity=Employee.class, cascade=CascadeType.ALL)
	@JoinColumn(name="deptno")
	private List<Employee>  empinfo;

	public int getDeptno() {
		return deptno;
	}

	public void setDeptno(int deptno) {
		this.deptno = deptno;
	}

	public String getDeptname() {
		return deptname;
	}

	public void setDeptname(String deptname) {
		this.deptname = deptname;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public List<Employee> getEmpinfo() {
		return empinfo;
	}

	public void setEmpinfo(List<Employee> empinfo) {
		this.empinfo = empinfo;
	}
	
	
}
