package coms.UploadAndDownloadFileService.service;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import coms.UploadAndDownloadFileService.model.FileInfo;
import coms.UploadAndDownloadFileService.repo.FileRepo;

@Service
public class FileInfoServiceImpl implements FileInfoService{

	@Autowired
	FileRepo  frepo;
	
	@Override
	public String FileUpload(MultipartFile file) {
		String res = "err";
		try
		{
		FileInfo fileinfo = new FileInfo();
		
		fileinfo.setFilename(file.getOriginalFilename());
		fileinfo.setFiletype(file.getContentType());
		
		fileinfo.setFiledata(file.getBytes());

		FileInfo f = frepo.save(fileinfo);
		if(f!=null)
			res ="Success";

		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
		}
		
		
		return res;
	}

	@Override
	public List<FileInfo> ShowAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public FileInfo GetAFile(String fileid) {
		// TODO Auto-generated method stub
		return null;
	}

}
