package coms.RestfullServiceApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestfullServiceAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestfullServiceAppApplication.class, args);
		System.out.println("Server Started....");
	}

}
