package coms.RestfullServiceWithJPA;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestfullServiceWithJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
