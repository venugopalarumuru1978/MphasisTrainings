package com.ifstmts;

public class OperEx {

	public static void main(String[] args) {
		int x = 10;
		System.out.println("Present Value : " + x);
		x++;
		System.out.println("Post Increment " + x);
		++x;
		System.out.println("Pre Increment " + x);
		
		int y = x++;
		System.out.println("Y = " + y + "\tX = " + x);
		int z = ++x;
		System.out.println("Z = " + z + "\tX = " + x);
	}
}
