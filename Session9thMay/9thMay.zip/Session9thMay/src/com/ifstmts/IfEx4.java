package com.ifstmts;
import java.util.Scanner;
public class IfEx4 {
	// Accept person age and gender then check marriage eligiblity based age and gender
	/*
	 * person gender male and age>=21 then eligible for marriage
	 * person gender female and age>=18 then eligible for marriage
	 */
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter gender of the person(Male/Female) ");
		String gender = sc.next();
		System.out.println("Enter age of the person ");
		int age = sc.nextInt();
		// Note :-  == operator will not work on strings because 
		// String is not a data type, it is a class and variables are the objects
		// on objects == will not work, equals() method has to be used.
		
		if(gender.equals("Male") || gender.equals("Female"))
		{
			if(gender.equals("Male"))
			{
				if(age>=21)
					System.out.println("Male Person eligible for Marriage");
				else
					System.out.println("Male Person not eligible for Marriage");
			}
			
			if(gender.equals("Female"))
			{
				if(age>=18)
					System.out.println("Female Person eligible for Marriage");
				else
					System.out.println("Female Person not eligible for Marriage");
			}
		}
		else
			System.out.println("Invalid Gender");
	}
}
