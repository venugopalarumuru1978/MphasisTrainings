package com.ifstmts;
import java.util.Scanner;
public class IfEx3 {
// Accept 3 numbers then find which is big number
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter 3 Numbers ");
		int x = sc.nextInt();
		int y = sc.nextInt();
		int z = sc.nextInt();
		
		if(x>y  && x>z)
			System.out.println(x + ", " + y + " and " + z + " big number is " + x);
		else if(y>x && y>z)
			System.out.println(x + ", " + y + " and " + z + " big number is " + y);
		else if(z>x && z>y)
			System.out.println(x + ", " + y + " and " + z + " big number is " + z);
		else
			System.out.println("Any two / all values are same");
	}
}
