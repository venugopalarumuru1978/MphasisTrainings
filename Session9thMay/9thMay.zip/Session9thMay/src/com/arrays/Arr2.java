package com.arrays;
import java.util.Scanner;
public class Arr2 {
	// Single Dimensional Array with dynamic process
	public static void main(String[] args) {
		int x[] = new int[5];

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter " + x.length + " Values");
		for(int i=0;i<x.length;i++)
		{
			x[i] = sc.nextInt();
		}
		System.out.println("Array Values ");
		int sum =0;
		for(int i=0;i<x.length;i++)
		{
			sum = sum+x[i];
			System.out.print(x[i] + "\t");
		}
		System.out.println("\nSum of array Values : " + sum);
	}

}
