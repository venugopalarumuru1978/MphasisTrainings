package com.arrays;

public class Arr5 {
	// Jagged Array with intilization
	public static void main(String[] args) {
		int x[][] = {{10,20,30},{40,50}, {60,70,80,90}};
		
		System.out.println("No of Rows : " + x.length);
		System.out.println("No of values in 1st row : " + x[0].length);
		System.out.println("No of values in 2nd row : " + x[1].length);
		System.out.println("No of values in 3rd row : " + x[2].length);
		
		for(int i=0;i<x.length;i++)
		{
			for(int j=0;j<x[i].length;j++)
			{
				System.out.print(x[i][j] + "\t");
			}
			System.out.println();
		}
	}
}
