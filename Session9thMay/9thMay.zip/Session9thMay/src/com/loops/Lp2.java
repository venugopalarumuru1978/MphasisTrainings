package com.loops;

public class Lp2 {
// Print all even number b/w 1 - 20 and vice  versa.
// 2 4  6 8 10 .... 20
	public static void main(String[] args) {

		int x = 2;
		while(x<=20)
		{
			System.out.print(x + "  ");
			x=x+2;
		}		
		System.out.println();  // line break
		x = 20;
		while(x>=1)
		{
			System.out.print(x + "  ");
			x = x-2;
		}
	}
}
