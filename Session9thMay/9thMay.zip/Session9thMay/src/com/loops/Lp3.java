package com.loops;

import java.util.Scanner;

public class Lp3 {
// Accept a number then check that number is prime no or not. 
// A number having only 2 factors(i.e. it is divisble by 1 and itself).
// 2 3 5  7  11, ...
	
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter any value ");
		int n = sc.nextInt();
		
		int i=1;
		int count=0;
		
		while(i<=n)
		{
			if(n%i==0)
			{
				count++;
			}
			i++;
		}
		
		if(count==2)
			System.out.println("Prime Number");
		else
			System.out.println("Not Prime Number");
	}
}
