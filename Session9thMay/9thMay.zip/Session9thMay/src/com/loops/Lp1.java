package com.loops;

public class Lp1 {

	public static void main(String[] args) {
		
		int x = 1;
		while(x<=5)
		{
			System.out.println(x + " Hello Java");
			x++;
		}
		System.out.println("----------");
		int y=5;
		while(y>=1)
		{
			System.out.println(y + " Hello java");
			y--;
		}
			
	}

}
