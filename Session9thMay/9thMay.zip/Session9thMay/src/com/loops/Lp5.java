package com.loops;

import java.util.Scanner;

public class Lp5 {
// Bill program of n number of products
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String ch = "";
		float grTotal = 0.0f;
		do
		{
		System.out.println("Enter Product Name : ");
		String pname = sc.next();
		
		System.out.println("Ener Product Price : ");
		float price = sc.nextFloat();
		
		System.out.println("Enter No of Items : ");
		int noi = sc.nextInt();
		
		float total = price*noi;
		grTotal = grTotal+total;
		
		System.out.println("Total Amount : " + total);
		System.out.println("1 More Product (y/n) ");
		ch = sc.next();
		}
		while(ch.equals("Y") || ch.equals("y"));
		System.out.println("Grand Total : " + grTotal);
	}
}
