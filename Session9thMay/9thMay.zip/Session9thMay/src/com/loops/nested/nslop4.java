package com.loops.nested;
/*
 * 1 2 3 4 5
 * 1 2 3 4
 * 1 2 3
 * 1 2
 * 1
 */

public class nslop4 {

	public static void main(String[] args) {
	
		int x = 5;
		while(x>=1)  //  no of rows
		{
			int y = 1;
			while(y<=x)  // no of columns
			{
				System.out.print(y + "  ");
				y++;
			}
			x--;
			System.out.println();
		}

		System.out.println("For Loop : ");
		for(int i=5;i>=1;i--)
		{
			for(int j=1;j<=i;j++)
			{
				System.out.print(j + "  ");
			}
			System.out.println();
		}
	}

}
