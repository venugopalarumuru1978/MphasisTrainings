package com.loops.nested;
/*
 * 1 2 3
 * 1 2 3
 * 1 2 3
 */
public class nslop2 {

	public static void main(String[] args) {
	
		int x = 1;
		while(x<=3)  //  no of rows
		{
			int y = 1;
			while(y<=3)  // no of columns
			{
				System.out.print(y + "  ");
				y++;
			}
			x++;
			System.out.println();
		}

		System.out.println("For Loop : ");
		for(int i=1;i<=3;i++)
		{
			for(int j=1;j<=3;j++)
			{
				System.out.print(j + "  ");
			}
			System.out.println();
		}
	}

}
