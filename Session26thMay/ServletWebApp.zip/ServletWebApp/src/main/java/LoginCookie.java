import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class LoginCookie
 */
@WebServlet("/LoginCookie")
public class LoginCookie extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginCookie() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		String uname = request.getParameter("txtUname");
		String pwd = request.getParameter("txtPwd");
		
		if(uname.equals("Venugopal")  &&  pwd.equals("venu@123"))
		{
			// In-Memory Cookie
			Cookie cok = new Cookie("user", uname);
			//cok.setMaxAge(1000); // 1000 milli seconds = 1 second
			response.addCookie(cok);
			
			response.sendRedirect("WelcomeCookie");
		}
		else
		{
			out.print("<p style='text-align:center;width:100%'>Error!... Please check username / password</p>");
			RequestDispatcher rd = request.getRequestDispatcher("LoginSession.html");
			rd.include(request, response);
		}
	}

}
