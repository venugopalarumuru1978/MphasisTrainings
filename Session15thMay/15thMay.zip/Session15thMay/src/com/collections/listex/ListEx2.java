package com.collections.listex;
import java.util.*;
public class ListEx2 {

	public static void main(String[] args) {
		List<Integer>  lstInt = new ArrayList<Integer>();
		lstInt.add(101);
		lstInt.add(102);
		lstInt.add(103);
		lstInt.add(104);
		lstInt.add(105);
		
		System.out.println(lstInt);
		
		// Traversing elements
		for(int n : lstInt)
		{
			System.out.println(n);
		}
		System.out.println("---------------");
		System.out.println("Using Iterator");
		System.out.println("---------------");
		
		Iterator  itr  = lstInt.iterator();
		
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		
	}

}
