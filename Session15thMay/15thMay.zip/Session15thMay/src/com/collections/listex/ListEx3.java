package com.collections.listex;
import java.util.*;
// Searching An Element
public class ListEx3 {

	public static void main(String[] args) {
		List<String>  lstStr = new ArrayList<String>();
		
		lstStr.add("Venugopal");
		lstStr.add("Srinivas");
		lstStr.add("SreeLakshmi");
		lstStr.add("Krishna Rao");
		lstStr.add("Laxmi");
		lstStr.add("Venugopal");
		
		System.out.println(lstStr);
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a value to search ");
		String str = sc.next();
		
		if(lstStr.contains(str))
			System.out.println("Element is Existed");
		else
			System.out.println("Element not existed");
	}

}
