package com.collections.listex;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class DeleteStudent {

	public static void main(String[] args) {
		List<Student>  lstStd = new ArrayList<Student>();

		Student std = new Student(1001, "Pavan", "Java", 10000.00f);
		lstStd.add(std);

		std = new Student(1002, "Karan", "Java", 10000.00f);
		lstStd.add(std);
		
		std = new Student(1003, "Sumathi", "Java", 10000.00f);
		lstStd.add(std);

		std = new Student(1004, "Karunya", "Java", 10000.00f);
		lstStd.add(std);

		std = new Student(1005, "Kamala", "Java", 10000.00f);
		lstStd.add(std);
		
		boolean b = false;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Roll Number to Delete: ");
		int rno = sc.nextInt();

		for(Student s : lstStd)
		{
			if(s.getRollno()==rno)
			{
				lstStd.remove(s);
				b = true;
				break;
			}
		}
		
		if(b==false)
			System.out.println("Student not found...");
		else
		{
			System.out.println("After Delete Student Details ");
			for(Student s : lstStd)
			{
				System.out.println(s.getRollno() + "\t" + s.getSname() + "\t" + s.getCourse() + "\t" + s.getFees());	
			}
		}
	}
}
