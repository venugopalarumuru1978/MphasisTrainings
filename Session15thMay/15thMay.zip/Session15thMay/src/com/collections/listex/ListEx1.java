package com.collections.listex;
import java.util.*;
public class ListEx1 {

	public static void main(String[] args) {
		List<String>  lstStr = new ArrayList<String>();
		
		lstStr.add("Venugopal");
		lstStr.add("Srinivas");
		lstStr.add("SreeLakshmi");
		lstStr.add("Krishna Rao");
		lstStr.add("Laxmi");
		lstStr.add("Venugopal");
		
		System.out.println(lstStr);
		
		/*
		 * foreach loop
		 * for(variable :  collectionObj)
		 * {
		 * 
		 * }
		 */
		// Traversing elements
		for(String str : lstStr)
		{
			System.out.println(str);
		}
		System.out.println("---------------");
		System.out.println("Using Iterator");
		System.out.println("---------------");
		Iterator  itr  = lstStr.iterator();
		
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		
	}

}
