package com.collections.listex.assignment;

public class Contact {

	private String personName;
	private long  phoneNumber;
	private String emailId;
	public String getPersonName() {
		return personName;
	}
	public void setPersonName(String personName) {
		this.personName = personName;
	}
	public long getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	
	public Contact(String personName, long phoneNumber, String emailId) {
		super();
		this.personName = personName;
		this.phoneNumber = phoneNumber;
		this.emailId = emailId;
	}
	
	
}
