package com.collections.listex.assignment;

import java.util.ArrayList;
import java.util.List;

public class PhoneBook {

	List<Contact>  phonebook = new ArrayList<Contact>();
	
	public void addContact(Contact contactObj)
	{
		phonebook.add(contactObj);
	}
	
	public List<Contact> viewAllContacts()
	{
		return phonebook;
	}
	
	public Contact viewContactGivenPhone(long phoneNumber)
	{
		Contact cnt = null;
		
		for(Contact c : phonebook)
		{
			if(c.getPhoneNumber()==phoneNumber)
			{
				cnt = c;
				break;
			}
		}
		return cnt;
	}
	
	public boolean removeContact(long phoneNumber)
	{
		boolean b = false;
		for(Contact c : phonebook)
		{
			if(c.getPhoneNumber()==phoneNumber)
			{
				phonebook.remove(c);
				b = true;
				break;
			}
		}
		
		return b;
	}
}
