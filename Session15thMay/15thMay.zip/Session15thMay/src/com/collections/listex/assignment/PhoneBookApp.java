package com.collections.listex.assignment;
import java.util.*;
public class PhoneBookApp {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		PhoneBook pb = new PhoneBook();
		Contact cnt = null;
		while(true)
		{
			System.out.println("1. Add Contact\n2. View All Contacts\n3. Search Contact based on Phone Number\n4. Remove Contact based on Phone Number\n5. Exit");
			System.out.println("Pick Ur Choice : ");
			int ch = sc.nextInt();
			
			switch(ch)
			{
			case 1:
				System.out.println("Person Name : ");
				String pname = sc.next();
				System.out.println("Phone Number : ");
				long ph = sc.nextLong();
				System.out.println("Email Id : ");
				String email = sc.next();
				cnt = new Contact(pname, ph, email);
				pb.addContact(cnt);
				System.out.println("-------------------");
				break;
			case 2:
				List<Contact>  c_all = pb.viewAllContacts();
				for(Contact c : c_all)
				{
					System.out.println(c.getPersonName() + "\t" + c.getPhoneNumber() + "\t" + c.getEmailId());
				}
				System.out.println("-------------------");
				break;
			case 3:
				System.out.println("Enter Phone Number");
				ph = sc.nextLong();
				Contact c = pb.viewContactGivenPhone(ph);
				if(c!=null)
					System.out.println(c.getPersonName() + "\t" + c.getPhoneNumber() + "\t" + c.getEmailId());
				else
					System.out.println("Contact not found....");
				System.out.println("-------------------");
				break;
			case 4:				
				System.out.println("Enter Phone Number");
				ph = sc.nextLong();
				boolean b = pb.removeContact(ph);
				if(b==true)
					System.out.println("Contact Deleted....");
				else
					System.out.println("Contact not found....");
				System.out.println("-------------------");
				break;
			case 5:
				System.out.println("Thanks for App");
				System.exit(0);
			}
		}
	}
}
