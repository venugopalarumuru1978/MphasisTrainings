package com.collections.listex;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class StdAdd2 {

	public static void main(String[] args) {
		List<Student>  lstStd = new ArrayList<Student>();
		Scanner sc = new Scanner(System.in);
		String ch = "";
		Student std = null;
		do
		{
			std = new Student();
			System.out.println("Roll Number ");
			std.setRollno(sc.nextInt());
			System.out.println("Student Name ");
			std.setSname(sc.next());
			System.out.println("Student Course ");
			std.setCourse(sc.next());
			System.out.println("Course Fees ");
			std.setFees(sc.nextFloat());
			lstStd.add(std);
			
			System.out.println("1 More Student(y/n) ");
			ch = sc.next();
		}
		while(ch.equalsIgnoreCase("y"));
		//System.out.println(lstStd);
		
		for(Student s : lstStd)
		{
			System.out.println(s.getRollno() + "\t" + s.getSname() + "\t" + s.getCourse() + "\t" + s.getFees());
		}
	
	}
}
