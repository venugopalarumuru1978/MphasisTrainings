package com.filespack;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class File4 {

	public static void main(String[] args) throws IOException {
		
		File  fileObj = new File("C:\\FilesInfo");
		
		String  fnames[] =  fileObj.list();
		int fcount=0, dcount=0;
		for(int i=0;i<fnames.length;i++)
		{
			System.out.println(fnames[i]);
			
			File temp = new File("C:\\FilesInfo\\" + fnames[i]);
			if(temp.isFile())
				fcount++;
			if(temp.isDirectory())
				dcount++;
		}
		
		System.out.println("No of Files : " + fcount);
		System.out.println("No of Folders : " + dcount);
		System.out.println("Total No of Items : " + fnames.length);
	}
}
