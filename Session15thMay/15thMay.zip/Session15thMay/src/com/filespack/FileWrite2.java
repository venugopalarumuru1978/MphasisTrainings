package com.filespack;

import java.io.*;
import java.util.*;
public class FileWrite2 {

	public static void main(String[] args) throws FileNotFoundException, IOException
	{
		Scanner sc = new Scanner(System.in);
	
		FileWriter fw = new FileWriter("C:\\FilesInfo\\Demo.txt", true);
		
		System.out.println("Enter Some Text : ");
		String str =  sc.nextLine();

		str = str + "\n";
		
		fw.write(str);
		
		fw.close();
		
		System.out.println("File Created/Updated....");
	}
}
