package com.filespack;

import java.io.*;
import java.util.*;
public class FileRead {

	public static void main(String[] args) throws FileNotFoundException, IOException
	{
		FileInputStream fis = new FileInputStream("C:\\FilesInfo\\abc.txt");
		
		int ch = fis.read();
		while(ch!=-1)
		{
			System.out.print((char)ch);
			ch = fis.read();
		}
		
		fis.close();
	}
}
