package com.filespack;

import java.io.*;
import java.util.*;
public class FileWrite {

	public static void main(String[] args) throws FileNotFoundException, IOException
	{
		Scanner sc = new Scanner(System.in);
	
		FileOutputStream  fos = new FileOutputStream("C:\\FilesInfo\\Abc.txt");
		
		System.out.println("Enter Some Text : ");
		String str =  sc.nextLine();
		
		byte[] arr = str.getBytes();  // it will convert string into bits and bytes.
		
		fos.write(arr); // writing data into a file.
		
		fos.close();
		
		System.out.println("Data Stored in a file");
	}
}
