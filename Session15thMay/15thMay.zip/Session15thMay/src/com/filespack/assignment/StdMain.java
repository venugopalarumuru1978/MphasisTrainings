package com.filespack.assignment;

import java.io.IOException;
import java.util.Scanner;

public class StdMain {

	public static void main(String[] args) throws IOException{
		StudentsData std = new StudentsData();
		Scanner sc = new Scanner(System.in);
		while(true)
		{
		System.out.println("1. Add New Student\n2. Show All Students\n3. Exit");
		System.out.println("Pick Ur Choice : ");
		int ch = sc.nextInt();
		
			switch(ch)
			{
			case 1:
				System.out.println("Roll Number : ");
				int rno = sc.nextInt();
				System.out.println("Student Name : ");
				String sname = sc.next();
				System.out.println("Course : ");
				String course =  sc.next();
				System.out.println("Course Fees : ");
				float fees = sc.nextFloat();
				
				String sinfo =  rno + "\t"  + sname + "\t" + course + "\t" + fees + "\n";
				std.AddNewStudent(sinfo);
				System.out.println("Student is Added...");
				break;
			case 2:
				std.ReadAllStudents();
				break;
			case 3:
					System.out.println("Thanks for using App.");
					System.exit(0);
			}
		}
	}
}
