package com.filespack.assignment;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class StudentsData {

	public void AddNewStudent(String stdinfo) throws IOException
	{
		FileWriter fw = new FileWriter("C:\\FilesInfo\\student.txt", true);
		fw.write(stdinfo);
		fw.close();
	}
	
	public void ReadAllStudents() throws IOException
	{
		FileReader fr = new FileReader("C:\\FilesInfo\\student.txt");
		BufferedReader br = new BufferedReader(fr);
		String str = br.readLine();
		while(str!=null)
		{
			System.out.println(str);
			str = br.readLine();
		}
		fr.close();
	}
}
