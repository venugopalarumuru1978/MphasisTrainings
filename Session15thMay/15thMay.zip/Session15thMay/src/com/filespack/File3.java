package com.filespack;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class File3 {

	public static void main(String[] args) throws IOException {
		//
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter filename to delete : ");
		String fname = sc.next();
		File  fileObj = new File("C:\\FilesInfo\\" + fname);
		
		if(fileObj.exists()==true)
		{
			fileObj.delete();
			System.out.println("File Deleted");
		}
		else
		{
			System.out.println("File Not Found.....");
		}
	}

}
