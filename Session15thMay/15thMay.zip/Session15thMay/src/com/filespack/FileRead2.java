package com.filespack;

import java.io.*;
import java.util.*;
public class FileRead2 {

	public static void main(String[] args) throws FileNotFoundException, IOException
	{
		FileReader fr = new FileReader("C:\\FilesInfo\\demo.txt");
		
		BufferedReader br = new BufferedReader(fr);
		
		String str = br.readLine();
		while(str!=null)
		{
			System.out.println(str);
			str = br.readLine();
		}
		fr.close();
	}
}
