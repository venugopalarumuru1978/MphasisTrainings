package coms.ImageUploadAndViewApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ImageUploadAndViewAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(ImageUploadAndViewAppApplication.class, args);
		System.out.println("Server Started...");
	}
}
