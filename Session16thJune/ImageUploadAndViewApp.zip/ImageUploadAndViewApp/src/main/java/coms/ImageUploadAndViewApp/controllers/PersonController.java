package coms.ImageUploadAndViewApp.controllers;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import coms.ImageUploadAndViewApp.Service.PersonService;
import coms.ImageUploadAndViewApp.model.Persons;

@Controller
public class PersonController {

	@Autowired
	PersonService ps;
	
	@GetMapping("/")
	public String HomePage(Model m)
	{
		m.addAttribute("person", new Persons());
		return "AddPersons";
	}
	
	@GetMapping("/person")
	public String AddPerson(Model m)
	{
		m.addAttribute("person", new Persons());
		return "AddPersons";
	}
	
	@PostMapping("/PersonAdd")
	public String AddPerson(@ModelAttribute  Persons person, Model m, @RequestParam("upimage") MultipartFile fileinfo) throws IOException
	{
		String fname = fileinfo.getOriginalFilename();
		byte[] filedata  = fileinfo.getBytes();
		person.setP_filename(fname);
		person.setPersonphoto(filedata);
		ps.AddPersons(person);
		m.addAttribute("msg", "Person Added");
		m.addAttribute("person", new Persons());
		return "AddPersons";
	}
	
	@GetMapping("/pall")
	public String GetAllPersons(Model m)
	{
		List<Persons>  personsAll = ps.ViewAll();
		m.addAttribute("personinfo", personsAll);
		return "ViewAllPersons";
	}
	
	@GetMapping("/getPersonPhoto/{id}")
	public void getPersonInfo(@PathVariable int id, HttpServletResponse response) throws IOException, SQLException
	{
		response.setContentType("image/jpeg");
		
		Blob ph =  ps.GetPhotoById(id);
		
		byte[] bytes = ph.getBytes(1, (int)ph.length());
		InputStream strm = new ByteArrayInputStream(bytes);
		IOUtils.copy(strm, response.getOutputStream());
	}
}
