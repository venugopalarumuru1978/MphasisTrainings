package coms.ImageUploadAndViewApp.Service;

import java.sql.Blob;
import java.util.List;

import coms.ImageUploadAndViewApp.model.Persons;

public interface PersonService {

	public String AddPersons(Persons per);
	public List<Persons>  ViewAll();
	public Blob GetPhotoById(int pid); 
}
