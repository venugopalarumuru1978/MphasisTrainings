package coms.ImageUploadAndViewApp.model;
/*
 * CREATE TABLE  PERSONINFO(PID INT auto_increment PRIMARY KEY,
PERSONAME VARCHAR(20),  PERSONPHOTO  LONGBLOB, P_FILENAME  VARCHAR(20));
 */
public class Persons {

	private  int pid;
	private  String personame;
	private  String p_filename;
	private  byte[] personphoto;
	
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getPersoname() {
		return personame;
	}
	public void setPersoname(String personame) {
		this.personame = personame;
	}
	public String getP_filename() {
		return p_filename;
	}
	public void setP_filename(String p_filename) {
		this.p_filename = p_filename;
	}
	public byte[] getPersonphoto() {
		return personphoto;
	}
	public void setPersonphoto(byte[] personphoto) {
		this.personphoto = personphoto;
	}
}
