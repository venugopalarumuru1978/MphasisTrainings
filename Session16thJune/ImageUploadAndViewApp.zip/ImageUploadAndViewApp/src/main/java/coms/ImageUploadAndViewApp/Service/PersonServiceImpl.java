package coms.ImageUploadAndViewApp.Service;

import java.sql.Blob;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import coms.ImageUploadAndViewApp.model.Persons;

@Service
public class PersonServiceImpl implements PersonService {

	@Autowired
	JdbcTemplate jt;
	
	@Override
	public String AddPersons(Persons per) {
		String ins = "Insert into personinfo(personame, p_filename, personphoto) values(?,?,?)";
		int res = jt.update(ins, new Object[] {per.getPersoname(), per.getP_filename(), per.getPersonphoto()});
		if(res>=1)
			return "Success";
		return "Err";
	}

	@Override
	public List<Persons> ViewAll() {
		List<Persons>  pall = jt.query("select * from Personinfo", new BeanPropertyRowMapper(Persons.class));
		return pall;
	}

	@Override
	public Blob GetPhotoById(int pid) {
		String qry = "Select personphoto from  personinfo where pid=?";
		
		Blob photo = jt.queryForObject(qry, new Object[] {pid}, Blob.class);
		
		return photo;
	}

}
