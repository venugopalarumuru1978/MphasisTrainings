package coms.ImageUploadAndViewApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ImageUploadAndViewAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
