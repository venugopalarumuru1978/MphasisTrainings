package coms.FileUploadAndDownloadWithStaticFolder.service;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import coms.FileUploadAndDownloadWithStaticFolder.model.FileInfo;
import coms.FileUploadAndDownloadWithStaticFolder.repo.FileRepo;


@Service
public class FileInfoServiceImpl implements FileInfoService{

	@Autowired
	FileRepo  frepo;
	
	@Override
	public String FileUpload(MultipartFile file) {
		String res = "err";
		try
		{
			// saving file into folder
			String path = "C:\\Mphasis\\SpringFrameworkApps\\FileUploadAndDownloadWithStaticFolder\\UploadedFiles\\" + file.getOriginalFilename();
			FileOutputStream fos = new FileOutputStream(path);
			fos.write(file.getBytes());
			fos.close();
			
			// saving file info into db
		FileInfo fileinfo = new FileInfo();
		
		fileinfo.setFilename(file.getOriginalFilename());
		fileinfo.setFiletype(file.getContentType());
		fileinfo.setFilesize(file.getBytes().length);

		FileInfo f = frepo.save(fileinfo);
		if(f!=null)
			res ="Success";

		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
		}
		return res;
	}

	@Override
	public List<FileInfo> ShowAll() {
		// TODO Auto-generated method stub
		return frepo.findAll();
	}

	@Override
	public FileInfo GetAFile(String fileid) {
		
		Optional<FileInfo>  fs = frepo.findById(fileid);
		
		if(fs.isPresent())
			return fs.get();
		return null;
	}

}
