package coms.FileUploadAndDownloadWithStaticFolder.service;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import coms.FileUploadAndDownloadWithStaticFolder.model.FileInfo;

public interface FileInfoService {
	public String FileUpload(MultipartFile file);
	public List<FileInfo>  ShowAll();
	public FileInfo GetAFile(String fileid);
}
