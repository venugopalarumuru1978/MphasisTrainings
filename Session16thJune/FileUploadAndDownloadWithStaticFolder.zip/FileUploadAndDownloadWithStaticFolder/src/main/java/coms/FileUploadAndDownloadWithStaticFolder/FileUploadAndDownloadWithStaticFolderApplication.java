package coms.FileUploadAndDownloadWithStaticFolder;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FileUploadAndDownloadWithStaticFolderApplication {

	public static void main(String[] args) {
		SpringApplication.run(FileUploadAndDownloadWithStaticFolderApplication.class, args);
		System.out.println("Server Started....");
	}
}
