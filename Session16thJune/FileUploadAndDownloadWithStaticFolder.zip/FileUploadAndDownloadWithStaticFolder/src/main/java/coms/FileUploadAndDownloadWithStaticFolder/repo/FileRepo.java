package coms.FileUploadAndDownloadWithStaticFolder.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import coms.FileUploadAndDownloadWithStaticFolder.model.FileInfo;

@Repository
public interface FileRepo extends JpaRepository<FileInfo, String> {

}
