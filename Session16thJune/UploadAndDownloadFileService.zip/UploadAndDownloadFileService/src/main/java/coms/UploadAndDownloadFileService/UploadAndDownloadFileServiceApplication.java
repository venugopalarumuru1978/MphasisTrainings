package coms.UploadAndDownloadFileService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UploadAndDownloadFileServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(UploadAndDownloadFileServiceApplication.class, args);
		System.out.println("Server Started...");
	}

}
