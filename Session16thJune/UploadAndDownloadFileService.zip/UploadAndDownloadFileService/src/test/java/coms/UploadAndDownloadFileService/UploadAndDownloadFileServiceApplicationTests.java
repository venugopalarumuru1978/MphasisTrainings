package coms.UploadAndDownloadFileService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UploadAndDownloadFileServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
