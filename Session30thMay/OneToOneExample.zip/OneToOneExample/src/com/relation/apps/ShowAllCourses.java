package com.relation.apps;

import java.util.List;

import javax.persistence.TypedQuery;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.relation.models.Address;
import com.relation.models.Courses;
import com.relation.models.Employee;
import com.relation.models.Faculty;

public class ShowAllCourses {

	public static void main(String[] args) {

		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf = cfg.buildSessionFactory();
		Session session = sf.openSession();

		TypedQuery  qry =  session.createQuery("from Courses");
		List<Courses>  clist =  qry.getResultList();
		
		for(Courses  c : clist)
		{
			System.out.println(c.getCid() + "\t" + c.getCoursename() + "\t" + c.getDuration() + "\t" +  c.getFact().getFacultyName() + "\t" + c.getFact().getCity());
		}
		
		session.close();
	}
}
