package com.relation.apps;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.relation.models.Address;
import com.relation.models.Courses;
import com.relation.models.Employee;
import com.relation.models.Faculty;

public class CourseApp {

	public static void main(String[] args) {

		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf = cfg.buildSessionFactory();
		Session session = sf.openSession();
		Transaction trans = session.beginTransaction();
		
		Faculty f = new Faculty();
		f.setFacultyName("Naresh Kumar");
		f.setCity("Hyd");
		
		Courses cur = new Courses();
		cur.setCoursename("Dotnet");
		cur.setDuration("6 Months");
		cur.setFact(f);
	
		
		session.persist(cur);
		trans.commit();
		
		session.close();
		sf.close();
		
		System.out.println("Tables are Created....");
	}
}
