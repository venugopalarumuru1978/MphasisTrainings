package com.relation.models;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table(name="EmpInfo")
public class Employee {

	@Id
	@GeneratedValue
	@PrimaryKeyJoinColumn   // which tells that it is an relationship based column
	private int empno;
	
	private String empname;
	
	@OneToOne(targetEntity = Address.class, cascade=CascadeType.ALL)
	private Address  adrs;

	public int getEmpno() {
		return empno;
	}

	public void setEmpno(int empno) {
		this.empno = empno;
	}

	public String getEmpname() {
		return empname;
	}

	public void setEmpname(String empname) {
		this.empname = empname;
	}

	public Address getAdrs() {
		return adrs;
	}

	public void setAdrs(Address adrs) {
		this.adrs = adrs;
	}
	
	
}
