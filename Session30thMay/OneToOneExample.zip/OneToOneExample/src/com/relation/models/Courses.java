package com.relation.models;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="CourseInfo")
public class Courses {

	@Id
	@GeneratedValue
	private int cid;
	
	private String coursename;
	private String duration;
	
	@OneToOne(targetEntity=Faculty.class, cascade=CascadeType.ALL)
	private Faculty fact;

	public int getCid() {
		return cid;
	}

	public void setCid(int cid) {
		this.cid = cid;
	}

	public String getCoursename() {
		return coursename;
	}

	public void setCoursename(String coursename) {
		this.coursename = coursename;
	}

	public String getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}

	public Faculty getFact() {
		return fact;
	}

	public void setFact(Faculty fact) {
		this.fact = fact;
	}
}
