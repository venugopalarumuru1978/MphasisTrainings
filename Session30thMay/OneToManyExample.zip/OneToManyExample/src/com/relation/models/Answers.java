package com.relation.models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="AnswersInfo")
public class Answers {

	@Id
	@GeneratedValue
	private int anid;
	
	private String answerinfo;
	private String givenBy;
	
	public int getAnid() {
		return anid;
	}
	public void setAnid(int anid) {
		this.anid = anid;
	}
	public String getAnswerinfo() {
		return answerinfo;
	}
	public void setAnswerinfo(String answerinfo) {
		this.answerinfo = answerinfo;
	}
	public String getGivenBy() {
		return givenBy;
	}
	public void setGivenBy(String givenBy) {
		this.givenBy = givenBy;
	}
	
	
}
