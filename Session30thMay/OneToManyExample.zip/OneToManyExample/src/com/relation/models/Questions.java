package com.relation.models;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OrderColumn;
import javax.persistence.Table;

@Entity
@Table(name="QuestionInfo")
public class Questions {

	@Id
	@GeneratedValue
	private int quid;

	private String qname;
	
	@OneToMany(targetEntity=Answers.class, cascade=CascadeType.ALL)
	@JoinColumn(name="quid")
	@OrderColumn(name="ind")
	private List<Answers> ans;

	public int getQuid() {
		return quid;
	}

	public void setQuid(int quid) {
		this.quid = quid;
	}

	public String getQname() {
		return qname;
	}

	public void setQname(String qname) {
		this.qname = qname;
	}

	public List<Answers> getAns() {
		return ans;
	}

	public void setAns(List<Answers> ans) {
		this.ans = ans;
	}
	
	
	
}
