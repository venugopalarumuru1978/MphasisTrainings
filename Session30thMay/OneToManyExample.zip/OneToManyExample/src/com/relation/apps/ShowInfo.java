package com.relation.apps;
import java.util.List;

import javax.persistence.TypedQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.relation.models.Answers;
import com.relation.models.Questions;

public class ShowInfo {

	public static void main(String[] args) {
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf = cfg.buildSessionFactory();
		Session session = sf.openSession();
		
		TypedQuery   qry = session.createQuery("from Questions");
		List<Questions>  qall =  qry.getResultList();
		
		for(Questions q : qall)
		{
			System.out.println("Q-" + q.getQuid() + " \t"  + q.getQname());
			List<Answers>  ansAll = q.getAns();
			for(Answers a : ansAll)
			{
				System.out.println(a.getAnswerinfo() + "\tGiven By : " + a.getGivenBy());
			}
		}
		session.close();
	}
}
