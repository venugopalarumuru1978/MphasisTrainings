package com.relation.apps;

import java.util.List;
import java.util.Scanner;

import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.relation.models.Department;

public class DeleteDept {

	public static void main(String[] args) {
		
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf = cfg.buildSessionFactory();
		Session session = sf.openSession();
		Transaction trans = session.beginTransaction();
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Deptno : ");
		int dno = sc.nextInt();
		TypedQuery  qry =  session.createQuery("from Department where deptno=:dno");
		qry.setParameter("dno", dno);
		List<Department> deptinfo = qry.getResultList();
		
		Department dept = deptinfo.get(0);
		
		session.delete(dept);
		trans.commit();
		
		session.close();
		System.out.println("Deleted....");
	}

}
