package com.relation.apps;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.relation.models.Department;
import com.relation.models.Employee;

public class EmpApp {

	public static void main(String[] args) {
	
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf = cfg.buildSessionFactory();
		Session session = sf.openSession();
		Transaction trans = session.beginTransaction();
		
		Department dept = new Department();
		dept.setDeptname("Education");
		dept.setLocation("Hyderabad");
		
		List<Employee>  empall = new ArrayList<Employee>();  
		Employee emp = new Employee();
		emp.setEmpno(1003);
		emp.setEmpname("Murali Kumar");
		emp.setJob("Manager");
		emp.setSalary(10000.00f);
		empall.add(emp);

		emp = new Employee();
		emp.setEmpno(1004);
		emp.setEmpname("Kalyan Kumar");
		emp.setJob("Developer");
		emp.setSalary(12000.00f);
		empall.add(emp);

		dept.setEmpinfo(empall);
		
		session.persist(dept);
		trans.commit();
		
		System.out.println("Emp Info Added....");
	}

}
