package com.relation.apps;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.relation.models.Answers;
import com.relation.models.Questions;

public class QuestionApp {

	public static void main(String[] args) {
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf = cfg.buildSessionFactory();
		Session session = sf.openSession();
		Transaction trans = session.beginTransaction();
		
		Questions q1 = new Questions();
		q1.setQname("What is a SQL?");
		
		Answers ans1 = new Answers();
		ans1.setAnswerinfo("It is a Structured Query Lang");
		ans1.setGivenBy("Renuka");

		Answers ans2 = new Answers();
		ans2.setAnswerinfo("It is an universal lang for db");
		ans2.setGivenBy("Kiran");


		List<Answers>  ans_all = new ArrayList<Answers>();
		ans_all.add(ans1);
		ans_all.add(ans2);
		
		q1.setAns(ans_all);
		
		session.persist(q1);
		trans.commit();
		
		session.close();
		System.out.println("Question  is Added....");
	}
}
