package com.jdbcpack;
import java.sql.*;
/*
 * Create following table in mySql before running this program
 * -------------------------
 * Create  table Employee(
empid int auto_increment primary key, 
empname varchar(20) not null, 
job varchar(10) not null, 
salary int);
-----------------
 */
public class AddNewRow {

	public static void main(String[] args) {
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conObj =  DriverManager.getConnection("jdbc:mysql://localhost:3306/MphasisDb", "root", "root");
			Statement stmt = conObj.createStatement();
			int res = stmt.executeUpdate("Insert into Employee(empname, job, salary) values('Kiran Kumar', 'Manager', 12000)");
			if(res>=1)
				System.out.println("Row Added....");
			conObj.close();
		}
		catch(Exception ex)
		{
			System.out.println(ex);
		}
	}
}
