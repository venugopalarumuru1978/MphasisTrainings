package com.jdbcpack;
import java.sql.*;
import java.util.Scanner;
/*
 * Create following table in mySql before running this program
 * -------------------------
 * Create  table Employee(
empid int auto_increment primary key, 
empname varchar(20) not null, 
job varchar(10) not null, 
salary int);
-----------------
 */
public class AddNewRowDynamically {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Employee Name : ");
		String ename = sc.next();
		System.out.println("Employee Job : ");
		String job = sc.next();
		System.out.println("Employee Salary : ");
		int sal = sc.nextInt();
		
		//Insert into Employee(empname, job, salary) values('Kiran Kumar', 'Manager', 12000)
		
		String  inscmd = "Insert into Employee(empname, job, salary) values('" +  ename + "','" + job + "'," + sal + ")";
		System.out.println(inscmd);
		
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conObj =  DriverManager.getConnection("jdbc:mysql://localhost:3306/MphasisDb", "root", "root");
			Statement stmt = conObj.createStatement();
			int res = stmt.executeUpdate(inscmd);
			if(res>=1)
				System.out.println("Row Added....");
			conObj.close();
		}
		catch(Exception ex)
		{
			System.out.println(ex);
		}
	}
}
