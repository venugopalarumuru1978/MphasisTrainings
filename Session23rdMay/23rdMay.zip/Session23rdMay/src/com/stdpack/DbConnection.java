package com.stdpack;
import java.sql.*;
public class DbConnection {
	
	public static Connection  getConnection()
	{
		Connection con = null;
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			con =  DriverManager.getConnection("jdbc:mysql://localhost:3306/MphasisDb", "root", "root");
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return con;
	}
}
