package com.sortingsandsearchings;

import java.util.Scanner;

public class BinarySearch {

	public static void main(String[] args) {
		int x[] = {10,20,30,40,50,60,70,80,90};
		
		System.out.println("Actual Values ");
		for(int n : x)
			System.out.print(n + "  ");
		
		Scanner sc = new Scanner(System.in);
		System.out.println("\nEnter a value to search ");
		int key = sc.nextInt();
		
		boolean b = false;

		int findex = 0;
		int lindex = x.length-1;
		
		while(findex<=lindex)
		{
			int mid =  (findex+lindex)/2; 
			
			if(key==x[mid])
			{
				System.out.println("Value found in " + (mid+1) + " Position");
				b = true;
				break;
			}
			
			if(x[mid]<key)
				findex = mid+1; 
			
			if(x[mid]>key)
				lindex = mid-1; 
		}

		if(b==false)
			System.out.println("Value Not Found...");
	}
}
