package com.sortingsandsearchings;

import java.util.Scanner;

public class LinearSearch {

	public static void main(String[] args) {
		int x[] = {10, 5,6, 7, 102, 45};
		
		System.out.println("Actual Values ");
		for(int n : x)
			System.out.print(n + "  ");
		
		Scanner sc = new Scanner(System.in);
		System.out.println("\nEnter a value to search ");
		int key = sc.nextInt();
		
		boolean b = false;
		for(int i=0;i<x.length;i++)
		{
			if(key==x[i])
			{
				System.out.println("Found Value in " + (i+1) + " Position");
				b = true;
				break;
			}
		}

		if(b==false)
			System.out.println("Value Not Found...");
	}
}
