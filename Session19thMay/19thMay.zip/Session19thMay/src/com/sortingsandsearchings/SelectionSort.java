package com.sortingsandsearchings;

public class SelectionSort {

	public static void main(String[] args) {
		
		int x[] = {10, 5, -7, 4, 8};
		
		System.out.println("Actual Values : ");
		for(int n : x)
		{
			System.out.print(n + "   ");
		}

		for(int i=0;i<x.length;i++)
		{
			int min_ind = i;
			
			for(int j=i+1;j<x.length;j++)
			{
				if(x[j]<x[min_ind])
				{
					min_ind = j;
				}
			}
			
			int smval = x[min_ind];
			x[min_ind] = x[i];
			x[i] = smval;
		}
		
		System.out.println("\nSorted Values in Asending Order : ");
		for(int n : x)
		{
			System.out.print(n + "   ");
		}
	}
}
