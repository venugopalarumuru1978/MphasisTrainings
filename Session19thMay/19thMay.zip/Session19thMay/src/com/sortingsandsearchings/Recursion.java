package com.sortingsandsearchings;

import java.util.*;
public class Recursion {
/*
	public static int Facotrial(int n)
	{
		int f = 1;
		while(n>0)
		{
			f = f*n;
			n--;
		}
		
		return f;
	}
*/
	// recursion
	public static int Facotrial(int n)
	{
		
		if(n==1)
			return 1;
		else if(n==0)
			return 0;
		else
		{
			return	n*Facotrial(n-1);  // recursion 	
		}
	}
	
	/*
	 * n=5
	 * 5*Facotrial(4)  = 120
	 * 5*4*Facotrial(3) = 120
	 * 5*4*3*Facotrial(2) = 120
	 * 5*4*3*2*Facotrial(1) = 120
	 * 5*4*3*2*1*Facotrial(0) = 120
	 */
	public static void main(String[] args) {
	
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter a value : ");
		int n = sc.nextInt();
		
		int fact = Facotrial(n);
		
		System.out.println(n + " Factorial Value is : " + fact);
	}

}
// using recursion
// Write a program to print fibnocci series values upto 10 numbers
// 1 1 2 3 5 8 13 21.....

