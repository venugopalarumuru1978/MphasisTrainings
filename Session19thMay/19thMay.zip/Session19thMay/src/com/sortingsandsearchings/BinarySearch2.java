package com.sortingsandsearchings;

import java.util.Arrays;
import java.util.Scanner;

public class BinarySearch2 {

	public static void main(String[] args) {
		
		int x[] = {10,20,30,40,50,60,70,80,90};
		
		System.out.println("Actual Values ");
		for(int n : x)
			System.out.print(n + "  ");
		
		Scanner sc = new Scanner(System.in);
		System.out.println("\nEnter a value to search ");
		int key = sc.nextInt();
		
		int res = Arrays.binarySearch(x, key);
		/*here if value present, it returns it's index value
		 *  if not it returns -ve value
		 */
		if(res<0)
			System.out.println("Value not Found");
		else
			System.out.println("Value found at " +(res+1) + " position");
	}
}
