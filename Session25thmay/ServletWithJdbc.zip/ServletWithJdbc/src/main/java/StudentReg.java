
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;
/**
 * Servlet implementation class StudentReg
 */
@WebServlet("/StudentReg")
public class StudentReg extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public StudentReg() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			String sname = request.getParameter("txtSname");
			String course = request.getParameter("txtCourse");
			String fees = request.getParameter("txtFees");
		
				response.setContentType("text/html");
				PrintWriter out = response.getWriter();
				
				
			try
			{
				Class.forName("com.mysql.cj.jdbc.Driver");
				Connection conObj =  DriverManager.getConnection("jdbc:mysql://localhost:3306/MphasisDb", "root", "root");

				String inscmd = "Insert into Student(stdname, course, fees) values(?,?,?)";
				PreparedStatement ps = conObj.prepareStatement(inscmd);
				ps.setString(1, sname);
				ps.setString(2, course);
				ps.setFloat(3, Float.parseFloat(fees));
				int r = ps.executeUpdate();
				if(r>=1)
				{
					response.sendRedirect("ShowAllStudents");
				}
				//conObj.close();
			}
			catch(Exception ex)
			{
				//res = ex.getMessage();
				ex.printStackTrace();
			}
	}
}
