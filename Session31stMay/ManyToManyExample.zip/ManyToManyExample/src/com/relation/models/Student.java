package com.relation.models;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="StudentsInfo")
public class Student {

	@Id
	@GeneratedValue
	private int rno;
	
	@Column(name="student_name")
	private String sname;
	
	private String location;

	@ManyToMany(cascade=CascadeType.ALL)
	private List<Courses>  courseinfo;
	
	public int getRno() {
		return rno;
	}

	public void setRno(int rno) {
		this.rno = rno;
	}

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public List<Courses> getCourseinfo() {
		return courseinfo;
	}

	public void setCourseinfo(List<Courses> courseinfo) {
		this.courseinfo = courseinfo;
	}
	
	
}
