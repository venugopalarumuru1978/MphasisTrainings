package com.relation.apps;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.relation.models.Courses;
import com.relation.models.Student;


public class CourseStdApp {

	public static void main(String[] args) {

		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf = cfg.buildSessionFactory();
		Session session = sf.openSession();
		Transaction trans = session.beginTransaction();
		
		Student std1 = new Student();
		std1.setSname("Pavan");
		std1.setLocation("Hyd");
		
		Student std2 = new Student();
		std2.setSname("Murali");
		std2.setLocation("Bgl");
		
		List<Student>  stdList = new ArrayList<Student>();
		stdList.add(std1);
		stdList.add(std2);
		
		Courses cur1 = new Courses();
		cur1.setCoursename("Java");
		cur1.setDuration("6 Months");
		
		Courses cur2 = new Courses();
		cur2.setCoursename("Python");
		cur2.setDuration("4 Months");
		
		List<Courses>  curList = new ArrayList<Courses>();
		curList.add(cur1);
		curList.add(cur2);
		
		std1.setCourseinfo(curList);
		std2.setCourseinfo(curList);
		
		cur1.setStdinfo(stdList);
		cur2.setStdinfo(stdList);
		
		session.persist(std1);
		session.persist(std2);
		
		session.persist(cur1);
		session.persist(cur2);
		
		trans.commit();
		
		System.out.println("Tables are Created....");
	}
}
