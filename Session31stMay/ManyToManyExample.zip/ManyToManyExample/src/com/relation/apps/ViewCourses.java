package com.relation.apps;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.relation.models.Courses;
import com.relation.models.Student;


public class ViewCourses {

	public static void main(String[] args) {

		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf = cfg.buildSessionFactory();
		Session session = sf.openSession();

		TypedQuery  qry = session.createQuery("from Courses");
		
		List<Courses>  curlist =  qry.getResultList();
		
		for(Courses c : curlist)
		{
			System.out.println(c.getCoursename() + "\t" + c.getDuration());
			System.out.println("Registered Students : ");
			List<Student> stdlist = c.getStdinfo();
			for(Student s : stdlist)
			{
				System.out.println(s.getSname() + "\t" + s.getLocation());
			}
			System.out.println("---------------");
		}
	}
}
