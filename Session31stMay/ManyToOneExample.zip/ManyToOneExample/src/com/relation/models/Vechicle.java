package com.relation.models;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="VechInfo")
public class Vechicle {

	@Id
	@GeneratedValue
	private int vechid;
	private String vechName;
	
	//@ManyToOne(targetEntity=Person.class,cascade =CascadeType.ALL)
	@ManyToOne(cascade =CascadeType.ALL)
	@JoinColumn(name="perid")
	private Person person;

	public int getVechid() {
		return vechid;
	}

	public void setVechid(int vechid) {
		this.vechid = vechid;
	}

	public String getVechName() {
		return vechName;
	}

	public void setVechName(String vechName) {
		this.vechName = vechName;
	}

	public Person getPerson() {
		return person;
	}

	public void setPerson(Person person) {
		this.person = person;
	}
}
