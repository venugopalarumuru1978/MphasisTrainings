package com.relation.apps;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.relation.models.Person;
import com.relation.models.Vechicle;

public class VechApp {

	public static void main(String[] args) {
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf = cfg.buildSessionFactory();
		Session session = sf.openSession();
		Transaction trans = session.beginTransaction();

		Person per = new Person();
		per.setPname("Praveen");
		per.setPhone("9900123645");
		
		Vechicle  v1 = new Vechicle();
		v1.setVechName("BMW");
		v1.setPerson(per);

		Vechicle  v2 = new Vechicle();
		v2.setVechName("AUDI");
		v2.setPerson(per);
		
		Vechicle  v3 = new Vechicle();
		v3.setVechName("RollsRoyces");
		v3.setPerson(per);
		
		session.persist(v1);
		session.persist(v2);
		session.persist(v3);
		trans.commit();
		
		System.out.println("Data Saved.....");
	}
}
