package com.relation.apps;

import java.util.List;

import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.relation.models.Vechicle;

public class ViewVechicles {

	public static void main(String[] args) {
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf = cfg.buildSessionFactory();
		Session session = sf.openSession();
		
		TypedQuery  qry = session.createQuery("from Vechicle");
		
		List<Vechicle> vall = qry.getResultList();
		
		for(Vechicle v : vall)
		{
			System.out.println(v.getVechid() + "\t" + v.getVechName() + "\t" + v.getPerson().getPname() + "\t" + v.getPerson().getPhone());
		}
	}
}
