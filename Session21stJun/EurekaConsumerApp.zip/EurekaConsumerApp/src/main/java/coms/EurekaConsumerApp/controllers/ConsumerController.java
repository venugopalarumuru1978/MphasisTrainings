package coms.EurekaConsumerApp.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping("/consumer")
public class ConsumerController {

	@Autowired
	private DiscoveryClient  client;
	
	@GetMapping("/cons1")
	public String TestMsg()
	{
		return "Hello - COnsumer";
	}
	
	@GetMapping("/pro-consume")
	public String ProviderAppCall()
	{
		RestTemplate rt1 = new RestTemplate();
				// it allows to get urls of the provider app/any web service urls
		List<ServiceInstance> list = client.getInstances("PROVIDER-APP");
		System.out.println(list);
		System.out.println("-------------");
		
		ResponseEntity<String> resp = rt1.getForEntity(list.get(0).getUri() + "/provider/show", String.class);
		System.out.println(resp);
		return  "Consumer : " + resp.getBody();
	}
}


// http://localhost:9098/provider/