package coms.EurekaConsumerApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaConsumerAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
