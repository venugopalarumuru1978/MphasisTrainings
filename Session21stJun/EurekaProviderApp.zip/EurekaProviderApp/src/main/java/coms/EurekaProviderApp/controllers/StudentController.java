package coms.EurekaProviderApp.controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import coms.EurekaProviderApp.model.Student;



@RestController
@RequestMapping("/stdprd")
public class StudentController {

	private static List<Student>  stdall = new ArrayList<Student>();
	
	@PostMapping("/stds")
	public ResponseEntity<Object>  addStudents(@RequestBody Student std)
	{
		stdall.add(std);
		return new ResponseEntity<Object>("Student Added...", HttpStatus.OK);
	}
	

	@GetMapping("/stds")
	public ResponseEntity<Object> ShowAll()
	{
		/*
		List<Student>  stdall = new ArrayList<Student>();
		Student std = new Student();
		std.setRollno(1001);
		std.setSname("Kiran");
		std.setCourse("Java");
		std.setFees(12000.00f);
		stdall.add(std);
		std = new Student();
		std.setRollno(1002);
		std.setSname("Karan");
		std.setCourse("Java");
		std.setFees(12000.00f);
		stdall.add(std);
		*/
		if(stdall.isEmpty())
			return new ResponseEntity<Object>("No Students Are Existed", HttpStatus.OK);
		
		return new ResponseEntity<Object>(stdall, HttpStatus.OK);
	}

	@GetMapping("/stds/{id}")
	public ResponseEntity<Object> GetOneStudent(@PathVariable  int id)
	{
		Student std = null;
		
		for(Student s : stdall)
		{
			if(s.getRollno()==id)
			{
				std = s;
				break;
			}
		}
		
		if(std!=null)
			return new ResponseEntity<Object>(std, HttpStatus.OK);
		
		return new ResponseEntity<Object>("Student Not Found", HttpStatus.NOT_FOUND);
	}
}
