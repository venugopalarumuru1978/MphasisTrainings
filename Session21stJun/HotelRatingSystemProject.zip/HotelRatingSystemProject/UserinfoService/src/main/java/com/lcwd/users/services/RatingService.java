package com.lcwd.users.services;

import java.util.List;

import com.lcwd.users.entites.RateInfo;
import com.lcwd.users.entites.Rating;

public interface RatingService {
	Rating CreateRating(Rating rate);
	List<RateInfo> getAll();
	List<RateInfo> RateInfoBasedOnHotelID(String hid);
	List<RateInfo> RateInfoBasedOnUserID(String uid);
	List<RateInfo> RateInfoBasedOnRating(int rid);
}
