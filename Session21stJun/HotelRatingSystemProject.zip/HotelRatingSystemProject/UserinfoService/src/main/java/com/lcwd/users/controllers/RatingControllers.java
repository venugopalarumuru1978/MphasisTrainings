package com.lcwd.users.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lcwd.users.entites.RateInfo;
import com.lcwd.users.entites.Rating;
import com.lcwd.users.services.RatingService;

@RestController
@RequestMapping("/rating")
public class RatingControllers {

	@Autowired
	RatingService rService;
	
	 	@PostMapping
	    public ResponseEntity<Rating> createRating(@RequestBody Rating rate) {
	        return ResponseEntity.status(HttpStatus.CREATED).body(rService.CreateRating(rate));
	    }
	 	
	 	  //get all
	    @GetMapping
	    public ResponseEntity<List<RateInfo>> getAllRatings(){
	    	System.out.println("Hello");
	        return ResponseEntity.ok(rService.getAll());
	    }
	    
	    //get rate info based hotel id
	    @GetMapping("/{hid}/{uid}/{rate}")
	    public ResponseEntity<List<RateInfo>> getRatingInfo(@PathVariable String hid,
	    		@PathVariable String uid,
	    		@PathVariable int rate) {
	    		List<RateInfo> ob1 = null;
	    		System.out.println(hid + "  " + uid + "  " + rate );
	    		if(!(hid.equals("0")) && uid.equals("0") && rate==0)
	    		{
	    			ob1 = rService.RateInfoBasedOnHotelID(hid);	
	    		}
	    		
	    		if(hid.equals("0") && !(uid.equals("0")) && rate==0)
	    		{
	    			 ob1 = rService.RateInfoBasedOnUserID(uid);	
	    		}

	    		if(hid.equals("0") && uid.equals("0") && rate!=0)
	    		{
	    			ob1 = rService.RateInfoBasedOnRating(rate);	
	    		}	    		
	    		return ResponseEntity.status(HttpStatus.OK).body(ob1);
	    }
}
