package com.lcwd.users.respositories;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.lcwd.users.entites.Rating;
@Repository
public interface RatingRepository extends JpaRepository<Rating, String> { 

}
