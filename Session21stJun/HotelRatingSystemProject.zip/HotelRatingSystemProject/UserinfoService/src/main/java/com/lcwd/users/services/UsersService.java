package com.lcwd.users.services;

import java.util.List;

import com.lcwd.users.entites.Users;

public interface UsersService {

    //create
    Users create(Users hotel);
    //get all
    List<Users> getAll();
    //get single
    Users get(String id);
}
