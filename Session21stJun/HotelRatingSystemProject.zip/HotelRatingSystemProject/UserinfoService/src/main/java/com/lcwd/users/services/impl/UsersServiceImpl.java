package com.lcwd.users.services.impl;

import com.lcwd.users.entites.Users;
import com.lcwd.users.exceptions.ResourceNotFoundException;
import com.lcwd.users.respositories.UsersRepository;
import com.lcwd.users.services.UsersService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
public class UsersServiceImpl implements UsersService {

    @Autowired
    private UsersRepository uRepository;

    @Override
    public Users create(Users user) {
        //String userid = UUID.randomUUID().toString();
        //hotel.setUserid(userid);
        return uRepository.save(user);
    }

    @Override
    public List<Users> getAll() {
        return uRepository.findAll();
    }

    @Override
    public Users get(String id) {
        return uRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("hotel with given id not found !!"));
    }
}
