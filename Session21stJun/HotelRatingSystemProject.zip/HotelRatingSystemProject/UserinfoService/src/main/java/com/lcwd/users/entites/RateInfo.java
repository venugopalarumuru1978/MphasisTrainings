package com.lcwd.users.entites;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class RateInfo {
	private String rid;
	private String hid, hname;
	private String uid, uname;
	private int rate;
}
