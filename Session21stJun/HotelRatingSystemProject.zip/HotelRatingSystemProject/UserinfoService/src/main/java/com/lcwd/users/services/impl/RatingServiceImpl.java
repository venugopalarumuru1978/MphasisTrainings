package com.lcwd.users.services.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lcwd.users.entites.Hotel;
import com.lcwd.users.entites.RateInfo;
import com.lcwd.users.entites.Rating;
import com.lcwd.users.entites.Users;
import com.lcwd.users.respositories.HotelRepository;
import com.lcwd.users.respositories.RatingRepository;
import com.lcwd.users.respositories.UsersRepository;
import com.lcwd.users.services.RatingService;

@Service
public class RatingServiceImpl implements RatingService {

	@Autowired
	RatingRepository rRepo;
	
	@Autowired
	HotelRepository hRepo;
	
	@Autowired
	UsersRepository uRepo;
	
	
	@Override
	public Rating CreateRating(Rating rate) {
		 String rateid = UUID.randomUUID().toString();
	     rate.setRid(rateid);   
	     return rRepo.save(rate);
	}

	
	@Override
	public List<RateInfo> getAll() {
		
		List<Hotel>  hotelinfo = hRepo.findAll();
		List<Users>  userinfo = uRepo.findAll();
		List<Rating>  ratinginfo = rRepo.findAll();
		
		
		
		RateInfo rinfo = null;
		List<RateInfo>  rating = new ArrayList<RateInfo>();
		for(Rating rt : ratinginfo)
		{
			rinfo = new RateInfo();
			rinfo.setHid(rt.getHid());
			String rid = rt.getRid();
			rinfo.setRid(rid);
			rinfo.setRate(rt.getRate());
			rinfo.setUid(rt.getUid());
			
				for(Hotel h : hotelinfo)
				{
					if(h.getId().equals(rt.getHid()))
					{
						rinfo.setHid(h.getId());
						rinfo.setHname(h.getName());
					}
				}
			
				for(Users u : userinfo)
				{
					if(u.getUserid().equals(rt.getUid()))
					{
						rinfo.setUid(u.getUserid());
						rinfo.setUname(u.getUname());
					}
				}
			
			rating.add(rinfo);	
		}
		return rating;
	}

	@Override
	public List<RateInfo> RateInfoBasedOnHotelID(String hid) {
		List<Hotel>  hotelinfo = hRepo.findAll();
		List<Users>  userinfo = uRepo.findAll();
		List<Rating>  ratinginfo = rRepo.findAll();
		
		
		RateInfo rinfo = null;
		List<RateInfo>  rating = new ArrayList<RateInfo>();
		for(Rating rt : ratinginfo)
		{
			if(rt.getHid().equals(hid) == true)
			{
			rinfo = new RateInfo();
			rinfo.setHid(rt.getHid());
			String rid = rt.getRid();
			rinfo.setRid(rid);
			rinfo.setRate(rt.getRate());
			rinfo.setUid(rt.getUid());
			
				for(Hotel h : hotelinfo)
				{
					if(h.getId().equals(rt.getHid()))
					{
						rinfo.setHid(h.getId());
						rinfo.setHname(h.getName());
					}
				}
			
				for(Users u : userinfo)
				{
					if(u.getUserid().equals(rt.getUid()))
					{
						rinfo.setUid(u.getUserid());
						rinfo.setUname(u.getUname());
					}
				}
			
			rating.add(rinfo);	
			}
		}
		return rating;
	}

	@Override
	public List<RateInfo> RateInfoBasedOnUserID(String uid) {
		List<Hotel>  hotelinfo = hRepo.findAll();
		List<Users>  userinfo = uRepo.findAll();
		List<Rating>  ratinginfo = rRepo.findAll();
		
		
		RateInfo rinfo = null;
		List<RateInfo>  rating = new ArrayList<RateInfo>();
		for(Rating rt : ratinginfo)
		{
			if(rt.getUid().equals(uid) == true)
			{
			rinfo = new RateInfo();
			rinfo.setHid(rt.getHid());
			String rid = rt.getRid();
			rinfo.setRid(rid);
			rinfo.setRate(rt.getRate());
			rinfo.setUid(rt.getUid());
			
				for(Hotel h : hotelinfo)
				{
					if(h.getId().equals(rt.getHid()))
					{
						rinfo.setHid(h.getId());
						rinfo.setHname(h.getName());
					}
				}
			
				for(Users u : userinfo)
				{
					if(u.getUserid().equals(rt.getUid()))
					{
						rinfo.setUid(u.getUserid());
						rinfo.setUname(u.getUname());
					}
				}
			
			rating.add(rinfo);	
			}
		}
		return rating;
	}

	@Override
	public List<RateInfo> RateInfoBasedOnRating(int rid) {
		List<Hotel>  hotelinfo = hRepo.findAll();
		List<Users>  userinfo = uRepo.findAll();
		List<Rating>  ratinginfo = rRepo.findAll();
		
		
		RateInfo rinfo = null;
		List<RateInfo>  rating = new ArrayList<RateInfo>();
		for(Rating rt : ratinginfo)
		{
			if(rt.getRate() == rid)
			{
			rinfo = new RateInfo();
			rinfo.setHid(rt.getHid());
			//String rid = rt.getRid();
			rinfo.setRid(rt.getRid());
			rinfo.setRate(rt.getRate());
			rinfo.setUid(rt.getUid());
			
				for(Hotel h : hotelinfo)
				{
					if(h.getId().equals(rt.getHid()))
					{
						rinfo.setHid(h.getId());
						rinfo.setHname(h.getName());
					}
				}
			
				for(Users u : userinfo)
				{
					if(u.getUserid().equals(rt.getUid()))
					{
						rinfo.setUid(u.getUserid());
						rinfo.setUname(u.getUname());
					}
				}
			
			rating.add(rinfo);	
			}
		}
		return rating;
	}
}
