package com.lcwd.users.controllers;

import com.lcwd.users.entites.Users;
import com.lcwd.users.services.UsersService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
//import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/users")
public class UserController {

    @Autowired
    private UsersService uService;

    //create
    @PostMapping
    public ResponseEntity<Users> createHotel(@RequestBody Users hotel) {
        return ResponseEntity.status(HttpStatus.CREATED).body(uService.create(hotel));
    }

    //get single
    @GetMapping("/{userid}")
    public ResponseEntity<Users> createHotel(@PathVariable String userid) {
        return ResponseEntity.status(HttpStatus.OK).body(uService.get(userid));
    }


    //get all
    @GetMapping
    public ResponseEntity<List<Users>> getAll(){
        return ResponseEntity.ok(uService.getAll());
    }


}
