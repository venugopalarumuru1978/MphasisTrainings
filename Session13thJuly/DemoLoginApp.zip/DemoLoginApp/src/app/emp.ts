export class Emp {
    id:number;
    ename:string;
    job:string;
    sal:number;

    constructor(id:number, en:string, jb:string, sl:number)
    {
        this.id = id;
        this.ename = en;
        this.job = jb;
        this.sal = sl;
    }
    
}
