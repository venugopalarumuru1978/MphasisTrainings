export class Emp {
    empno:number;
    ename:string;
    job:string;
    sal:number;

    constructor(eno:number, en:string, jb:string, sl:number)
    {
        this.empno = eno;
        this.ename = en;
        this.job = jb;
        this.sal = sl;
    }
}
