package com.ds;

public class TestQueue {

	public static void main(String[] args) {
		
		Queue  q = new Queue(5);
		q.EnQueue(10);
		q.EnQueue(20);
		q.EnQueue(30);
		q.EnQueue(40);
		q.EnQueue(50);
		//q.EnQueue(10);
		
		q.ShowAll();
		
		for(int i=1;i<=q.Size();i++)
		{
			System.out.println("\nRemoved ..." + q.DeQueue());
			q.ShowAll();
		}
		
		q.EnQueue(100);
		q.EnQueue(200);
		

		q.ShowAll();
		
		for(int i=1;i<=q.Size();i++)
		{
			System.out.println("\nRemoved ..." + q.DeQueue());
			q.ShowAll();
		}
	}

}
