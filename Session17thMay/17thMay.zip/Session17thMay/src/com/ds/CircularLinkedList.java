package com.ds;

public class CircularLinkedList {

	class Node
	{
		int data;
		Node next;
		
		public Node(int x)
		{
			this.data = x;
			this.next = null;
		}
	}
	

	private Node head = null;
	private Node tail = null;
	
	public void addNode(int data)
	{
		Node newNode = new Node(data);
		
		if(head==null)
		{
			head = newNode;
			tail = newNode;
			newNode.next = head;
		}
		else
		{
			tail.next = newNode;
			tail = newNode;
			tail.next = head;
		}
	}
	
	public void ShowAll()
	{
		Node currentnode = head;
		
		if(head==null)
		{
			System.out.println("List is Empty");
			return;
		}

		do
		{
			System.out.print(currentnode.data + "  ");
			currentnode = currentnode.next;
		}
		while(currentnode!=head);
	}
}
