package com.ds;

public class Stack {
	
	private int arr[];
	private int capacity;
	private int top;
	
	public Stack(int size)
	{
		arr = new int[size];
		capacity = size;
		top = -1;
	}
	
	public boolean isEmpty()
	{
		if(top==-1)
			return true;
		else 
			return false;
	}
	
	public boolean isFull()
	{
		if(top==capacity-1)
			return true;
		else
			return false;
	}
	
	public void Push(int n)
	{
		if(this.isFull())
		{
			System.out.println("Stack Full...Overflow");
			System.exit(0);
		}
		
		arr[++top] = n;
		System.out.println("Added Value : " + n);
	}
	
	public int Pop()
	{
		if(this.isEmpty())
		{
			System.out.println("Stack is Empty....");
			System.exit(0);
		}
		
		return arr[top--];
	}
	
	public void ShowAll()
	{
		System.out.print("[");
		for(int i=0;i<=top;i++)
		{
			System.out.print(arr[i] + ", ");
		}
		System.out.print("]");
	}
	
	public int Size()
	{
		return capacity;
	}
}
