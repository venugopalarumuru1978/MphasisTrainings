package com.ds;

public class SingleLinkedList {

	class Node
	{
		int data;
		Node next;
		
		public Node(int x)
		{
			this.data = x;
			this.next = null;
		}
	}
	

	private Node head = null;
	private Node tail = null;
	
	public void addNode(int data)
	{
		// Create a new Node
		Node newNode = new Node(data);
		
		if(head==null)
		{
			// if list is empty, both head and tail will point to new node
			head = newNode;
			tail = newNode;
		}
		else
		{
			// newNode will be added after tail such tails next will point to newnode
			tail.next = newNode;
			//new node will be tail (last)
			tail = newNode;
		}
	}
	
	public void ShowAll()
	{
		Node newnode = head;
		
		if(head==null)
		{
			System.out.println("List is Empty");
			return;
		}
		
		while(newnode!=null)
		{
			System.out.print(newnode.data + "  ");
			newnode = newnode.next;
		}
	}
}
