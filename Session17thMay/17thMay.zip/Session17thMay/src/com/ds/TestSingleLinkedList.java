package com.ds;

public class TestSingleLinkedList {

	public static void main(String[] args) {
		
		SingleLinkedList sll = new SingleLinkedList();
		sll.addNode(100);
		sll.addNode(200);
		sll.addNode(300);
		sll.addNode(400);
		sll.addNode(500);
		
		sll.ShowAll();
		
		sll.addNode(600);
		System.out.println();

		sll.ShowAll();
	}

}
