package com.ds;

public class DoublyLinkedListTest {

	public static void main(String[] args) {

		DoublyLinkedList  dll = new DoublyLinkedList();
		dll.addNode(100);
		dll.addNode(200);
		dll.addNode(300);
		dll.addNode(400);
		dll.addNode(500);
		dll.addNode(600);
		
		dll.ShowValuesInForward();
		System.out.println();
		dll.ShowValuesInBackward();
	}
}
