package com.ds;

public class DoublyLinkedList {

	class Node
	{
		private int data;
		private Node pre, next;
		
		public Node(int data)
		{
			this.data = data;
			this.pre = null;
			this.next =  null;
		}
	}
	
	public Node head = null, tail=null;

	public void addNode(int data)
	{
		Node newNode = new Node(data);
		
		if(head==null)
		{
			head = newNode;
			tail = newNode;
			head.pre =  null;
			tail.next = null;
		}
		else
		{
			tail.next = newNode;
			newNode.pre = tail;
			tail = newNode;
			tail.next = null;
		}	
	}
	
	public void ShowValuesInForward()
	{
		Node current = head;
		
		if(head==null)
		{
			System.out.println("List is Empty");
			return;
		}
		
		while(current!=null)
		{
			System.out.print(current.data  + "  ");
			current = current.next;
		}
	}
	public void ShowValuesInBackward()
	{
		Node current = tail;
		
		if(tail==null)
		{
			System.out.println("List is Empty");
			return;
		}
		
		while(current!=null)
		{
			System.out.print(current.data  + "  ");
			current = current.pre;
		}
	}
}
