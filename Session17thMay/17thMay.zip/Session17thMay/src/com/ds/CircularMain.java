package com.ds;

public class CircularMain {

	public static void main(String[] args) {
		CircularLinkedList  cll = new CircularLinkedList();
		cll.addNode(100);
		cll.addNode(200);
		cll.addNode(300);
		cll.addNode(400);
		cll.addNode(500);
		
		cll.ShowAll();
	}
}
