package com.ds;

public class Queue {
	private int arr[];
	private int front,rear;
	private int capacity;
	
	public Queue(int size)
	{
		arr = new int[size];
		front = -1;
		rear = -1;
		capacity = size;
	}
	
	public boolean isEmpty()
	{
		if(front==-1)
			return true;
		else
			return false;
	}
	
	public boolean isFull()
	{
		if(front==0 && rear==capacity-1)
			return true;
		else
			return false;
	}
	
	public void EnQueue(int val)
	{
		if(this.isFull())
		{
			System.out.println("Queue is Full...Overflow");
		}
		else
		{
			if(front==-1)
				front = 0;
			rear++;
			arr[rear] = val;
			System.out.println("Value is Added.." + val);
		}
	}
	
	public int DeQueue()
	{
		if(this.isEmpty())
		{
			System.out.println("Queue is Empty....");
			return 0;
		}
		else
		{
			int element = arr[front];
			if(front>=rear)
			{
				front = -1;
				rear =  -1;
			}
			else
				front++;
			//System.out.println("Removed : " + element);
			return element;
		}
	}
	
	public void ShowAll()
	{
		if(!this.isEmpty())
		{
			for(int i=front;i<=rear;i++)
				System.out.print(arr[i] + " ");
		}		
	}
	
	public int MaxSize()
	{
		return capacity;
	}
	
	public int Size()
	{
		return rear+1;
	}
}
