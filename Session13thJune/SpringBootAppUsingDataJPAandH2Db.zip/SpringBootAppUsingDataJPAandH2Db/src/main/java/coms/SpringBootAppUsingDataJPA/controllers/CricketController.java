package coms.SpringBootAppUsingDataJPA.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import coms.SpringBootAppUsingDataJPA.model.Cricket;
import coms.SpringBootAppUsingDataJPA.service.CricketService;

@Controller
public class CricketController {

	@Autowired
	CricketService  cs;

	@GetMapping(value="/")
	public String DefaultPage(Model m)
	{
		List<Cricket> crkAll = cs.ShowAll();
		m.addAttribute("call", crkAll);
		return "ViewAllCricketers";
	}

	
	@GetMapping(value="/add")
	public String NewCricketer(Model m)
	{
		m.addAttribute("crk", new Cricket());
		return "AddCricketer";
	}
	
	@PostMapping(value="/addn")
	public String NewCricketer(@ModelAttribute("crk") Cricket crk,
			Model m)
	{		
		if(cs.AddNewCricketer(crk).equals("Success"))
		{
			m.addAttribute("crk", new Cricket());
			m.addAttribute("msg", "Details are Added...");
		}
		return "AddCricketer";
	}
	
	@GetMapping(value="/vall")
	public String ViewAll(Model m)
	{
		List<Cricket> crkAll = cs.ShowAll();
		m.addAttribute("call", crkAll);
		return "ViewAllCricketers";
	}
	
	@GetMapping(value="/search")
	public String SearchCriketer(Model m)
	{
		return "SearchCrk";
	}
	
	@PostMapping(value="/fetchInfo")
	public String SearchCriketer(@RequestParam("txtCid") int cid,  Model m)
	{
		Cricket crk = cs.Search(cid);
		if(crk!=null)
			m.addAttribute("crk", crk);
		else
			m.addAttribute("msg", "Cricketer Not Found...");
		return "SearchCrk";
	}
	
	@GetMapping(value="/del")
	public String DelCriketer(@RequestParam("crkId") int cno)
	{
		cs.DeleteCricketer(cno);
		return "redirect:/vall";
	}
	
	
	@GetMapping(value="/mod")
	public String UpdateCriketer(@RequestParam("crkId") int cno, Model m)
	{
		Cricket crk = cs.Search(cno);
		m.addAttribute("crk", crk);
		return "ModifyCrk";
	}
		
	@PostMapping(value="/modn")
	public String ModifyCricketer(@ModelAttribute("crk") Cricket crk,
			Model m)
	{
/*
		Cricket  crk = new Cricket();
		crk.setCrid(cid);
		crk.setCrkname(cname);
		crk.setGame(game);
		crk.setRuns(runs);
	*/	
		cs.ModifyCricketer(crk);
		
		return "redirect:/vall";
	}
}
