package com.hibernate.service;

import java.io.Serializable;
import java.util.List;

import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.stereotype.Service;
import com.hibernate.config.HiberConfig;
import com.hibernate.model.Cricket;

@Service
public class CricketServiceImpl implements CricketService {

	private Session sObj = null;
	
	public CricketServiceImpl()
	{
		sObj = HiberConfig.getConnection();
	}
	
	public String AddNewCricketer(Cricket crk) {
		
		String result = "err";
		Transaction trns = sObj.beginTransaction();
		Serializable  s = sObj.save(crk);
		trns.commit();
		
		if(s!=null)
			result = "Success";
		return result;
	}

	public List<Cricket> ShowAll() {
		sObj = HiberConfig.getConnection();
		TypedQuery  qry = sObj.createQuery("from Cricket");
		List<Cricket>  cAll = qry.getResultList();
		return cAll;
	}

	public Cricket Search(int crno) {
		Cricket crk = null;
		crk = (Cricket)sObj.load(Cricket.class, new Integer(crno));
		return crk;
	}

	public void ModifyCricketer(Cricket crk) {
		
		
		Transaction trns = sObj.beginTransaction();
		TypedQuery qry = sObj.createQuery("Update Cricket set crkname=:cna, game=:g, runs=:r where crid=:cid");
		qry.setParameter("cna", crk.getCrkname());
		qry.setParameter("g", crk.getGame());
		qry.setParameter("r", crk.getRuns());
		qry.setParameter("cid", crk.getCrid());
		qry.executeUpdate();
		trns.commit();
	}

	public void DeleteCricketer(int crno) {
		Cricket	crk = (Cricket)sObj.load(Cricket.class, new Integer(crno));
		if(crk!=null)
		{
			sObj.delete(crk);
			Transaction trns = sObj.beginTransaction();
			trns.commit();
		}
	}
}
