package com.hibernate.service;

import java.util.List;

import com.hibernate.model.Cricket;

public interface CricketService {
	public String AddNewCricketer(Cricket crk);
	public List<Cricket> ShowAll();
	public Cricket  Search(int crno);
	public void ModifyCricketer(Cricket crk);
	public void DeleteCricketer(int crno);
}
