package com.hibernate.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.hibernate.model.Cricket;
import com.hibernate.service.CricketService;

@Controller
public class CricketController {

	@Autowired
	CricketService cs;
	
	@GetMapping(value="/add")
	public String AddCric(Model m)
	{
		m.addAttribute("crk", new Cricket());
		return "AddCricketer";
	}
	
	@PostMapping(value="/addn")
	public String AddCric(@ModelAttribute("crk") Cricket crk, Model m)
	{
		cs.AddNewCricketer(crk);
		m.addAttribute("crk", new Cricket());
		m.addAttribute("msg", "Added New Cricketer");
		return "AddCricketer";
	}
	
	@GetMapping(value="/vall")
	public String ViewAll(Model m)
	{
		List<Cricket> call = cs.ShowAll();
		m.addAttribute("call", call);
		return "ViewAllCricketers";
	}
	
	@GetMapping(value="/del")
	public String DelCric(@RequestParam("crkId") int cno,  Model m)
	{
		cs.DeleteCricketer(cno);
		return "redirect:/vall";
	}
	
	@GetMapping(value="/mod")
	public String ModCric(@RequestParam("crkId") int cno,  Model m)
	{
		Cricket crk = cs.Search(cno);
		m.addAttribute("crk", crk);
		return "ModifyCrk";
	}
	
	@PostMapping(value="/modn")
	public String ModCric(@ModelAttribute("crk") Cricket crk, Model m)
	{
		cs.ModifyCricketer(crk);
		return "redirect:/vall";
	}
}
