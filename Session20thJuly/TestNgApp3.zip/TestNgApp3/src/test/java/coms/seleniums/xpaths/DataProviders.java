package coms.seleniums.xpaths;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class DataProviders {

	@Test(dataProvider = "LoginInfo")
	public void TestProviders(String user, String pass) throws Exception
	{
		WebDriver driver = new ChromeDriver();
		WebDriverManager.chromedriver().setup();
		//driver.manage().window().maximize();
		driver.get("file:///C:/WeekendDesigningSessions/Ex4.html");
		driver.findElement(By.name("txtUser")).sendKeys(user);
		Thread.sleep(2000);
		driver.findElement(By.name("txtPass")).sendKeys(pass);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@value='Click Me']")).submit();
		Assert.assertEquals(true, driver.findElement(By.id("welcome")).isDisplayed());
		Thread.sleep(2000);
		driver.quit();
	}
	
	@DataProvider(parallel = true)
	public Object[][] LoginInfo()
	{
		Object[][] data = new Object[6][2];
		data[0][0] = "venugopal";
		data[0][1] = "v@123";
		
		data[1][0] = "satyam";
		data[1][1] = "s@123";

		data[2][0] = "satyams";
		data[2][1] = "ss@123";

		data[3][0] = "naresh";
		data[3][1] = "n@123";

		data[4][0] = "mahesh";
		data[4][1] = "m@123";

		data[5][0] = "venugopal";
		data[5][1] = "v@123";

		return data;
	}
}
