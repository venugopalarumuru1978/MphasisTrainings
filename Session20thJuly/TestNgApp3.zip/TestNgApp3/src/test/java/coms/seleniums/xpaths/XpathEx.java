package coms.seleniums.xpaths;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
import io.github.bonigarcia.wdm.WebDriverManager;

public class XpathEx {

	@Test
	public void XpathExample1()
	{
		WebDriver driver = new ChromeDriver();
		WebDriverManager.chromedriver().setup();
		driver.manage().window().maximize();
		driver.get("https://www.w3schools.com/");
		WebElement element = driver.findElement(By.xpath("//a[@title='Exercises and Quizzes' ]"));
		highlight(driver,element);
		driver.findElement(By.xpath("//a[@title='Exercises and Quizzes']")).click();
	}
	
	@Test
	public void XpathExample2()
	{
		WebDriver driver = new ChromeDriver();
		WebDriverManager.chromedriver().setup();
		driver.manage().window().maximize();
		driver.get("https://www.w3schools.com/");
		WebElement element = driver.findElement(By.xpath("//a[@title='Tutorials and References' and @id='navbtn_tutorials']"));
		highlight(driver,element);
	}

	@Test
	public void XpathExample3()
	{
		WebDriver driver = new ChromeDriver();
		WebDriverManager.chromedriver().setup();
		driver.manage().window().maximize();
		driver.get("https://www.w3schools.com/");
		WebElement element = driver.findElement(By.xpath("//a[contains(text(),'Services')]"));
		highlight(driver,element);
	}

	
	
	
	public static void highlight(WebDriver driver, WebElement element) {
		JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
		jsExecutor.executeScript("arguments[0].setAttribute('style', 'border:2px solid red; background:yellow')", element);
	}
}

//
