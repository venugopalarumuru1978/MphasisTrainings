package coms.screencapture;

import java.io.File;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

import io.github.bonigarcia.wdm.WebDriverManager;

public class BaseTest {

	public static WebDriver driver;
	public static String subfoldername;
	
	@BeforeTest
	public void setup()
	{
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().window().maximize();
	}
	
	@AfterMethod
	public void screenShotcapture(ITestResult result)
	{
		if(result.getStatus()== ITestResult.FAILURE)
		{
			String fname = result.getTestContext().getName() + "_" + result.getMethod().getMethodName() + ".jpg";
			captureScreenShot(fname);
		}
	}
	
	@AfterTest
	public void CloseProcess()
	{
		driver.quit();
	}
	
	public void captureScreenShot(String fileName)
	{
		if(subfoldername==null)
		{
			LocalDateTime  myDateObj = LocalDateTime.now();
			DateTimeFormatter myFormat = DateTimeFormatter.ofPattern("ddMMyyyyHHmmss");
			subfoldername = myDateObj.format(myFormat);
		}
		
		TakesScreenshot  takesScreen = (TakesScreenshot) driver;
		File sourcefile = takesScreen.getScreenshotAs(OutputType.FILE);
		File destFile = new File("./ScreenShots/" +  subfoldername + "/" + fileName);
		try
		{
			FileUtils.copyFile(sourcefile, destFile);
		}
		catch(Exception ex)
		{
			System.out.println(ex);
		}
		System.out.println("Screenshot Saved Successfully...");
	}
}


