package coms.reports;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class DemoTests extends BaseTest {

	@Test(testName="DemoTest1")
	public void TestGoogle() throws Exception
	{
				driver.get("https://www.google.com/");
				driver.findElement(By.name("q")).sendKeys("java tutorial", Keys.ENTER);
				System.out.println("Page Title is : " + driver.getTitle());
				String expected = "java tutorial - Google Search";
				String actual = driver.getTitle();
				Assert.assertEquals(actual, expected, "Both are Mismatched...");			
				extentTest.pass("Assertion is Passed for Webpage Title");
	}
	
	@Test(testName="DemoTest2")
	public void TestFaceBook() throws Exception
	{
		driver.get("http://www.facebook.com/");
		
		driver.findElement(By.name("email")).sendKeys("venugopal@gmail.com", Keys.ENTER);
		System.out.println("Page Title is : " + driver.getTitle());
		
		SoftAssert  soft = new SoftAssert(); 
		
		// Title Assertion
		String expected="Log in to Facebook";
		String actual = driver.getTitle();
		//soft.assertEquals(actual, expected, "Title Mismatch");
		soft.assertTrue(actual.equals(expected), "Title Mismatch");
		
		//URL Assertion
		String expectedUrl="http://www.facebook.com/";
		String actualUrl = driver.getCurrentUrl();
		soft.assertEquals(actualUrl, expectedUrl, "URL Mismatch");
		
		// Text Assertion :- textbox is empty or not
		String actualText = driver.findElement(By.name("email")).getAttribute("value");
		String expectedText = "venugopal@gmail.com";
		soft.assertEquals(actualText, expectedText, "Text is Mismatch");
		
		// Border assertion
		//1px solid #f02849  = hexa decimal color
		//1px solid rgb(240, 40, 73) = rgb color
		String actualBorder = driver.findElement(By.name("email")).getCssValue("border");
		String expectedBorder = "1px solid rgb(221, 223, 226)";
		System.out.println(actualBorder);
		soft.assertEquals(actualBorder, expectedBorder, "Border color mismatch");
		soft.assertAll();  // it will provide error report.
	}
}
