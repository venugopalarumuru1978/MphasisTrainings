package coms.CustomLoginApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomLoginAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomLoginAppApplication.class, args);
	}
}


//ref : https://www.javaguides.net/2023/04/spring-security-custom-login-page.html