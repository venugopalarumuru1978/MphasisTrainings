package com.LoginAndLogout;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@EnableWebSecurity
@ComponentScan("com.LoginAndLogout")
public class WebSpringMvcConfig implements WebMvcConfigurer {

		//Authentication
  	@Bean
    public UserDetailsService userDetailsService() throws Exception {  
        InMemoryUserDetailsManager manager = new InMemoryUserDetailsManager();  
        manager
        		.createUser(User.withDefaultPasswordEncoder()
        		.username("venugopal")
        		.password("12345")
        		.roles("USER")
        		.build());
        return manager;  
    }  
  	
  	/*
  	 * UserDetailsService: this interface allows to hold users and their roles
  	 * It has to use an implemented class InMemoryUserDetailsManager 
  	 *Roles :-  
  	 *			USER
  	 *			ADMIN
  	 */
  	//Authorization process
  	 protected void configure(HttpSecurity http) throws Exception {  
         
  		http                              
        .authorizeRequests()  
        .anyRequest()
        .hasRole("USER")  
            .and()
            .formLogin() // fetch the login page
            .and()  
            .httpBasic()  
            .and()  
            .logout()  
            .logoutUrl("/logout")  
            .logoutSuccessUrl("/"); 
     }
}
